# Section 1: Les Fondamentaux de l'Allocation entre Lignes d'Actions

## Introduction

Bienvenue dans cette première section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Nous allons explorer les principes fondamentaux qui sous-tendent une allocation efficace entre différentes actions, en commençant par comprendre les concepts clés qui guideront vos décisions d'investissement.

## Définition et Importance de l'Allocation

L'allocation entre lignes d'actions est le processus qui consiste à déterminer quelle proportion de votre portefeuille doit être investie dans chaque action. Cette décision est cruciale car elle influence directement :

- Le niveau de risque global de votre portefeuille
- Le potentiel de rendement à long terme
- La stabilité de la performance dans différentes conditions de marché

Pour un club d'investissement comme le vôtre, qui se concentre exclusivement sur les actions, l'allocation entre différentes lignes devient d'autant plus importante, car c'est votre principal levier pour gérer le risque et optimiser les rendements.

## Le Concept de Corrélation entre Actions

### Qu'est-ce que la Corrélation?

La corrélation mesure la relation entre les mouvements de prix de deux actions. Elle est exprimée par un coefficient qui varie de -1 à +1 :

- **Corrélation de +1** : Les actions évoluent de manière parfaitement identique
- **Corrélation de 0** : Aucune relation linéaire entre les mouvements des actions
- **Corrélation de -1** : Les actions évoluent de manière exactement opposée

### Pourquoi la Corrélation Est-Elle Importante?

La corrélation est un concept fondamental pour deux raisons principales :

1. **Réduction du risque** : En combinant des actions faiblement corrélées entre elles, vous pouvez réduire la volatilité globale de votre portefeuille.
2. **Optimisation du rendement** : Une diversification basée sur la corrélation permet d'améliorer le ratio rendement/risque de votre portefeuille.

### Exemple Concret

Prenons deux secteurs : la technologie et les services financiers.

- Pendant les périodes de croissance économique, ces secteurs peuvent avoir une corrélation positive modérée (environ +0,5).
- Pendant les crises financières, cette corrélation peut augmenter fortement (jusqu'à +0,8 ou plus).
- En période d'innovation technologique mais de restrictions réglementaires bancaires, la corrélation peut diminuer ou même devenir négative.

En comprenant ces dynamiques, vous pouvez ajuster votre allocation pour mieux naviguer dans différents environnements de marché.

## L'Impact de la Volatilité sur le Portefeuille d'Actions

### Comprendre la Volatilité

La volatilité mesure l'ampleur des variations de prix d'une action sur une période donnée. Une action très volatile connaît des mouvements de prix importants, tandis qu'une action peu volatile a des mouvements de prix plus modérés.

### Volatilité et Allocation

La volatilité d'une action influence directement son poids optimal dans un portefeuille :

- **Actions à forte volatilité** : Généralement, elles devraient avoir une pondération plus faible pour limiter leur impact sur la volatilité globale du portefeuille.
- **Actions à faible volatilité** : Elles peuvent avoir une pondération plus importante, car elles contribuent moins à la volatilité globale.

Cependant, il est important de noter qu'un portefeuille composé uniquement d'actions, même avec une bonne répartition, reste globalement plus volatil qu'un portefeuille diversifié entre différentes classes d'actifs.

### Exemple Pratique

Considérons deux actions :
- Action A : Volatilité annuelle de 30% (ex: une jeune entreprise technologique)
- Action B : Volatilité annuelle de 15% (ex: une entreprise de services publics établie)

Dans un portefeuille équilibré en termes de risque, l'action B pourrait avoir une pondération plus importante que l'action A, même si cette dernière offre potentiellement un rendement supérieur.

## Risque Systématique vs Risque Non-Systématique

### Deux Types de Risques

Lorsque vous investissez en actions, vous êtes confronté à deux types de risques :

1. **Risque systématique (ou risque de marché)** :
   - Affecte l'ensemble du marché
   - Ne peut pas être éliminé par la diversification
   - Exemples : récessions économiques, crises financières, pandémies

2. **Risque non-systématique (ou risque spécifique)** :
   - Propre à une entreprise ou un secteur particulier
   - Peut être réduit ou éliminé par la diversification
   - Exemples : mauvaise gestion d'une entreprise, problèmes réglementaires spécifiques à un secteur

### Implications pour l'Allocation

La distinction entre ces deux types de risques a des implications importantes pour votre stratégie d'allocation :

- **Diversification efficace** : Elle permet d'éliminer une grande partie du risque non-systématique, mais n'a pas d'impact sur le risque systématique.
- **Nombre optimal d'actions** : Des études montrent qu'un portefeuille de 15 à 30 actions bien diversifiées permet d'éliminer environ 90% du risque non-systématique.
- **Sélection sectorielle** : La diversification entre secteurs est souvent plus efficace que la diversification au sein d'un même secteur pour réduire le risque non-systématique.

### Application Pratique

Pour votre club d'investissement, cela signifie qu'il est crucial de :
- Maintenir un nombre suffisant de lignes d'actions (idéalement 15-30)
- Diversifier entre différents secteurs économiques
- Accepter que même un portefeuille parfaitement diversifié reste exposé au risque systématique

## Quiz Interactif: Testez votre Compréhension des Corrélations

### Question 1:
Quelle est la corrélation probable entre une action bancaire et une action technologique?
- a) Forte positive (proche de +1)
- b) Faible positive (entre 0 et +0,5)
- c) Négative (entre -1 et 0)
- d) Nulle (proche de 0)

**Réponse correcte: b) Faible positive (entre 0 et +0,5)**

**Explication:** Les actions bancaires et technologiques évoluent généralement dans la même direction lors des mouvements majeurs du marché (d'où une corrélation positive), mais leurs performances peuvent diverger significativement en fonction des conditions économiques spécifiques, des taux d'intérêt et de l'innovation (d'où une corrélation relativement faible).

### Question 2:
Si deux actions ont une corrélation de -0,8, que se passe-t-il généralement lorsque l'une augmente de 10%?
- a) L'autre augmente d'environ 8%
- b) L'autre diminue d'environ 8%
- c) L'autre ne bouge pas
- d) Impossible à déterminer

**Réponse correcte: b) L'autre diminue d'environ 8%**

**Explication:** Une corrélation fortement négative (-0,8) indique que les deux actions évoluent généralement dans des directions opposées avec une magnitude similaire. Si une action augmente de 10%, l'autre aura tendance à diminuer d'environ 8%.

### Question 3:
Quel est l'avantage principal d'inclure dans votre portefeuille des actions ayant une faible corrélation entre elles?
- a) Augmentation garantie du rendement
- b) Élimination complète du risque
- c) Réduction de la volatilité globale du portefeuille
- d) Simplification de la gestion du portefeuille

**Réponse correcte: c) Réduction de la volatilité globale du portefeuille**

**Explication:** Combiner des actions faiblement corrélées permet de réduire la volatilité globale du portefeuille, car lorsqu'une action performe mal, les autres peuvent performer différemment, lissant ainsi les fluctuations de valeur du portefeuille dans son ensemble.

### Question 4:
Combien d'actions différentes faut-il généralement détenir pour éliminer environ 90% du risque non-systématique?
- a) 5 à 10 actions
- b) 15 à 30 actions
- c) 50 à 100 actions
- d) Plus de 100 actions

**Réponse correcte: b) 15 à 30 actions**

**Explication:** Des études empiriques ont montré qu'un portefeuille contenant entre 15 et 30 actions bien diversifiées (entre secteurs, géographies, etc.) permet d'éliminer environ 90% du risque non-systématique. Au-delà, le bénéfice marginal de diversification diminue considérablement.

## Graphique Interactif: Impact de la Corrélation sur le Risque du Portefeuille

[Note: Cette section contiendra un graphique interactif montrant comment la volatilité d'un portefeuille à deux actifs varie en fonction de leur corrélation. L'utilisateur pourra ajuster les niveaux de corrélation pour voir l'impact sur la volatilité globale.]

## Points Clés à Retenir

- L'allocation entre lignes d'actions est cruciale pour gérer le risque et optimiser le rendement de votre portefeuille.
- La corrélation entre actions est un concept fondamental pour construire un portefeuille efficace.
- La volatilité des actions individuelles influence leur poids optimal dans le portefeuille.
- La diversification permet d'éliminer une grande partie du risque non-systématique, mais pas le risque systématique.
- Un portefeuille de 15 à 30 actions bien diversifiées permet d'atteindre un niveau de diversification optimal.

## Prochaine Section

Dans la section suivante, nous explorerons les différentes stratégies de diversification que vous pouvez mettre en œuvre au sein de votre portefeuille d'actions, notamment la diversification sectorielle, géographique, par taille de capitalisation et par style d'investissement.
