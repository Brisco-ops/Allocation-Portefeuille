# Section 4: Gestion Dynamique de l'Allocation et Rééquilibrage

## Introduction

Bienvenue dans cette quatrième section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Après avoir exploré les fondamentaux, les stratégies de diversification et les méthodologies d'allocation, nous allons maintenant nous concentrer sur la gestion dynamique de l'allocation et le rééquilibrage du portefeuille.

Un portefeuille d'actions n'est pas une entité statique. Les prix des actions évoluent constamment, modifiant ainsi les pondérations initiales. De plus, les conditions de marché, les perspectives sectorielles et les fondamentaux des entreprises changent au fil du temps. Cette section vous présentera les principes et les techniques pour maintenir votre portefeuille aligné avec vos objectifs et vos convictions.

## Principes du Rééquilibrage Périodique du Portefeuille

### Définition et Objectifs du Rééquilibrage

Le rééquilibrage est le processus qui consiste à ajuster les pondérations des différentes lignes d'actions dans votre portefeuille pour les ramener à leur allocation cible ou pour refléter une nouvelle allocation cible.

**Objectifs principaux du rééquilibrage :**
- Maintenir le profil risque/rendement souhaité
- Éviter la concentration excessive dans certaines actions ou secteurs
- Capitaliser sur les opportunités de marché
- Mettre en œuvre les changements de conviction ou de stratégie

### Approches de Rééquilibrage

#### Rééquilibrage Calendaire

Cette approche consiste à rééquilibrer le portefeuille à intervalles réguliers prédéfinis.

**Fréquences courantes :**
- Mensuelle
- Trimestrielle
- Semestrielle
- Annuelle

**Avantages :**
- Simplicité et discipline
- Réduction des décisions émotionnelles
- Planification facilitée

**Inconvénients :**
- Ne tient pas compte des conditions de marché
- Peut entraîner des transactions inutiles
- Peut manquer des opportunités entre les périodes de rééquilibrage

**Recommandation pour un club d'investissement :**
Une fréquence trimestrielle ou semestrielle est souvent un bon compromis, coïncidant avec les réunions régulières du club.

#### Rééquilibrage par Seuils

Cette approche consiste à rééquilibrer le portefeuille lorsque les pondérations s'écartent significativement de leur allocation cible.

**Exemples de seuils :**
- Écart absolu : Rééquilibrer si une action s'écarte de plus de 3-5 points de pourcentage de son allocation cible
- Écart relatif : Rééquilibrer si une action s'écarte de plus de 20-30% de son allocation cible

**Avantages :**
- Réduction des transactions inutiles
- Adaptation aux mouvements de marché
- Focus sur les écarts significatifs

**Inconvénients :**
- Suivi plus régulier nécessaire
- Peut entraîner des transactions fréquentes en période de volatilité
- Complexité accrue

**Recommandation pour un club d'investissement :**
Définir des seuils d'alerte (±20% de l'allocation cible) pour discussion lors des réunions régulières, et des seuils d'action (±30% de l'allocation cible) pour intervention plus rapide.

#### Rééquilibrage Opportuniste

Cette approche consiste à rééquilibrer le portefeuille en fonction des opportunités de marché ou des changements fondamentaux.

**Déclencheurs typiques :**
- Corrections de marché significatives
- Événements spécifiques à une entreprise (résultats, acquisitions, etc.)
- Changements macroéconomiques ou sectoriels importants

**Avantages :**
- Capitalisation sur les opportunités
- Adaptation aux changements fondamentaux
- Potentiel de surperformance

**Inconvénients :**
- Risque de décisions émotionnelles
- Peut entraîner des transactions fréquentes
- Nécessite une analyse continue

**Recommandation pour un club d'investissement :**
Combiner avec une approche calendaire ou par seuils, en permettant des ajustements opportunistes dans un cadre défini et après discussion collective.

### Coûts et Bénéfices du Rééquilibrage

#### Coûts du Rééquilibrage

- **Coûts de transaction** : Frais de courtage, écarts bid-ask, impact de marché
- **Implications fiscales** : Réalisation de plus-values imposables
- **Coûts d'opportunité** : Vente potentielle d'actions surperformantes
- **Coûts de temps et d'effort** : Analyse, prise de décision, exécution

#### Bénéfices du Rééquilibrage

- **Maintien du profil risque/rendement** : Alignement avec les objectifs et la tolérance au risque
- **Discipline d'investissement** : Protection contre les biais comportementaux
- **Effet "buy low, sell high"** : Vente automatique des actions qui ont surperformé, achat de celles qui ont sous-performé
- **Adaptation aux changements** : Évolution de la stratégie en fonction des nouvelles conditions

#### Optimisation du Rapport Coûts/Bénéfices

Pour optimiser le rapport coûts/bénéfices du rééquilibrage :
- Limitez la fréquence des rééquilibrages (trimestrielle ou semestrielle)
- Utilisez des seuils significatifs (±20-30% de l'allocation cible)
- Combinez le rééquilibrage avec d'autres transactions nécessaires
- Considérez l'impact fiscal dans le timing des transactions
- Utilisez les flux de trésorerie entrants/sortants pour ajuster les allocations

## Identification des Signaux Déclencheurs de Réallocation

Au-delà du simple rééquilibrage vers des allocations cibles fixes, il est important d'identifier les signaux qui pourraient justifier une modification de ces allocations cibles elles-mêmes.

### Signaux Fondamentaux

Ces signaux sont liés aux changements dans les fondamentaux des entreprises.

**Exemples de signaux fondamentaux :**
- Détérioration significative des résultats financiers
- Changements majeurs dans la direction ou la stratégie
- Perte d'avantages compétitifs
- Problèmes réglementaires ou juridiques
- Acquisitions ou cessions majeures

**Comment les surveiller :**
- Suivi des publications de résultats
- Lecture des communiqués de presse et rapports annuels
- Analyse des appels avec les analystes
- Suivi des nouvelles sectorielles

### Signaux Techniques

Ces signaux sont liés aux mouvements de prix et aux tendances du marché.

**Exemples de signaux techniques :**
- Ruptures de tendances majeures
- Formations chartistes significatives
- Divergences entre prix et indicateurs
- Volumes anormalement élevés
- Comportement par rapport aux moyennes mobiles clés

**Comment les surveiller :**
- Analyse régulière des graphiques
- Utilisation d'alertes techniques
- Suivi des indicateurs de momentum
- Analyse des volumes de transaction

### Signaux Macroéconomiques et Sectoriels

Ces signaux sont liés aux changements dans l'environnement économique global ou sectoriel.

**Exemples de signaux macroéconomiques et sectoriels :**
- Changements dans les politiques monétaires
- Évolutions des indicateurs économiques clés
- Disruptions technologiques sectorielles
- Changements réglementaires affectant un secteur
- Évolutions géopolitiques majeures

**Comment les surveiller :**
- Suivi des annonces des banques centrales
- Analyse des indicateurs économiques
- Veille technologique et réglementaire
- Suivi de l'actualité géopolitique

### Signaux de Valorisation

Ces signaux sont liés aux niveaux de valorisation des actions ou des secteurs.

**Exemples de signaux de valorisation :**
- Écarts significatifs par rapport aux valorisations historiques
- Divergences importantes entre valorisations sectorielles
- Anomalies de valorisation par rapport aux fondamentaux
- Extrêmes de sentiment de marché

**Comment les surveiller :**
- Suivi régulier des ratios de valorisation
- Comparaisons historiques et sectorielles
- Analyse des révisions d'estimations des analystes
- Suivi des indicateurs de sentiment

### Signaux de Conviction

Ces signaux sont liés aux changements dans les convictions du club d'investissement.

**Exemples de signaux de conviction :**
- Nouvelles analyses approfondies
- Changements dans les thèses d'investissement
- Évolution des priorités ou de la stratégie du club
- Nouvelles opportunités identifiées

**Comment les surveiller :**
- Discussions régulières au sein du club
- Revues périodiques des thèses d'investissement
- Partage continu d'informations entre membres
- Évaluation régulière des convictions

## Stratégies de Rotation Sectorielle

La rotation sectorielle est une stratégie qui consiste à modifier l'allocation entre différents secteurs économiques en fonction du cycle économique ou d'autres facteurs.

### Rotation Basée sur le Cycle Économique

Cette approche ajuste l'allocation sectorielle en fonction des différentes phases du cycle économique.

**Phases du cycle et secteurs typiquement favorisés :**

1. **Début de reprise :**
   - Secteurs cycliques : Consommation discrétionnaire, Finance
   - Secteurs sensibles aux taux : Immobilier

2. **Expansion :**
   - Secteurs de croissance : Technologie, Industrie
   - Secteurs liés aux matières premières : Matériaux, Énergie

3. **Ralentissement :**
   - Secteurs défensifs : Santé, Services publics
   - Secteurs à dividendes stables : Télécommunications

4. **Récession :**
   - Secteurs défensifs : Consommation de base, Santé
   - Secteurs moins sensibles au cycle : Services publics

**Avantages :**
- Alignement avec les tendances économiques
- Potentiel de surperformance
- Approche structurée

**Inconvénients :**
- Difficulté à identifier précisément les phases du cycle
- Décalages possibles entre cycle économique et performance sectorielle
- Risque de timing incorrect

### Rotation Basée sur les Tendances Séculaires

Cette approche ajuste l'allocation sectorielle en fonction des tendances à long terme qui transcendent les cycles économiques.

**Exemples de tendances séculaires :**
- Digitalisation et transformation numérique
- Vieillissement démographique
- Transition énergétique et développement durable
- Automatisation et intelligence artificielle
- Évolution des habitudes de consommation

**Secteurs potentiellement favorisés :**
- Technologie, Cybersécurité, Cloud computing
- Santé, Biotechnologie, Services aux seniors
- Énergies renouvelables, Efficacité énergétique
- Robotique, Logiciels d'IA
- E-commerce, Économie de l'expérience

**Avantages :**
- Horizon d'investissement plus long
- Moins de transactions nécessaires
- Exposition aux moteurs de croissance structurels

**Inconvénients :**
- Valorisations parfois élevées des secteurs tendance
- Risque de surinvestissement dans des tendances qui ne se matérialisent pas
- Nécessité d'une analyse approfondie

### Rotation Basée sur la Valorisation Relative

Cette approche ajuste l'allocation sectorielle en fonction des valorisations relatives des différents secteurs.

**Principe :**
- Surpondérer les secteurs relativement sous-évalués
- Sous-pondérer les secteurs relativement surévalués
- Utiliser des métriques comme P/E, P/B, P/S relatifs à la moyenne historique ou au marché

**Avantages :**
- Approche disciplinée et quantitative
- Potentiel de "mean reversion"
- Réduction du risque de surpayer

**Inconvénients :**
- Les valorisations peuvent rester extrêmes pendant longtemps
- Nécessité d'ajuster pour les différences structurelles entre secteurs
- Peut conduire à investir dans des secteurs en difficulté structurelle

### Mise en Œuvre de la Rotation Sectorielle

Pour mettre en œuvre efficacement une stratégie de rotation sectorielle dans un club d'investissement :

1. **Définir une approche principale** (cycle économique, tendances séculaires, valorisation)
2. **Établir des indicateurs clés** à surveiller pour chaque secteur
3. **Définir des seuils de déclenchement** pour les ajustements d'allocation
4. **Documenter les décisions** et leurs justifications
5. **Évaluer régulièrement l'efficacité** de la stratégie
6. **Combiner différentes approches** pour une stratégie plus robuste

## Exercice Pratique: Fiche d'Arbitrage de Portefeuille

### Présentation de la Fiche d'Arbitrage

La fiche d'arbitrage est un outil pratique qui permet de structurer et de documenter les décisions de réallocation au sein du portefeuille. Elle sert à la fois d'aide à la décision et de trace pour l'historique des arbitrages.

**Modèle de fiche d'arbitrage simplifiée :**

| Champ | Description |
|-------|-------------|
| Date de l'arbitrage | Date à laquelle l'arbitrage est effectué |
| Ligne(s) à vendre | Action(s) dont la position doit être réduite ou liquidée |
| Motif de vente | Raison justifiant la vente (conviction disparue, valorisation excessive, etc.) |
| Valorisation actuelle | Cours actuel et valorisation relative (P/E, etc.) |
| Montant réalisé | Montant total obtenu après la vente |
| Ligne(s) à renforcer/initier | Action(s) dont la position doit être augmentée ou initiée |
| Justification | Raisons justifiant l'achat (fondamentaux solides, valorisation attractive, etc.) |
| Allocation avant/après | Pourcentages d'allocation avant et après l'arbitrage |
| Effet sur le portefeuille | Impact attendu sur le profil risque/rendement du portefeuille |
| Décision | Collective ou par comité d'investissement |
| Suivi | Date prévue pour évaluer l'efficacité de l'arbitrage |

### Exemple Concret d'Arbitrage

Voici un exemple d'application de la fiche d'arbitrage à un cas concret :

**Date de l'arbitrage :** 15 juin 2025

**Ligne à vendre :** Orpéa

**Motif de vente :**
- Conviction disparue suite à des problèmes de gouvernance
- Détérioration des perspectives sectorielles
- Risques réglementaires accrus

**Valorisation actuelle :**
- Cours : 32,50 €
- P/E : 15,2x (vs moyenne historique de 18,5x)
- EV/EBITDA : 9,8x (vs moyenne sectorielle de 10,5x)

**Montant réalisé :** 2 000 € (vente de 62 actions)

**Lignes à renforcer :**
1. Air Liquide (1 200 €)
2. Schneider Electric (800 €)

**Justification :**
- Air Liquide :
  - Fondamentaux solides et business model résilient
  - Exposition aux tendances de l'hydrogène et de la transition énergétique
  - Dividende stable et croissant
  
- Schneider Electric :
  - Leader dans l'efficacité énergétique
  - Forte exposition aux marchés en croissance
  - Momentum positif sur les résultats

**Allocation avant/après :**
- Orpéa : 3,5% → 0%
- Air Liquide : 4,2% → 6,3%
- Schneider Electric : 3,8% → 5,2%

**Effet sur le portefeuille :**
- Réduction du risque réglementaire
- Augmentation de l'exposition aux thématiques de transition énergétique
- Amélioration de la qualité globale du portefeuille
- Légère réduction du rendement du dividende

**Décision :** Votée à l'unanimité lors de la réunion du club du 10 juin 2025

**Suivi :** Évaluation prévue lors de la réunion trimestrielle de septembre 2025

### Application Interactive

[Note: Cette section contiendra un outil interactif permettant aux utilisateurs de remplir leur propre fiche d'arbitrage, avec des conseils et des validations automatiques pour chaque champ.]

## Quiz Interactif: Scénarios de Réallocation

### Question 1:
Dans quel cas le rééquilibrage par seuils serait-il préférable au rééquilibrage calendaire?
- a) Lorsque le marché est très stable
- b) Lorsque le marché est très volatil
- c) Lorsque les coûts de transaction sont très élevés
- d) Lorsque le portefeuille est très diversifié

**Réponse correcte: c) Lorsque les coûts de transaction sont très élevés**

**Explication:** Avec des coûts de transaction élevés, le rééquilibrage par seuils permet de limiter les transactions aux cas où les écarts sont suffisamment importants pour justifier ces coûts, contrairement au rééquilibrage calendaire qui peut entraîner des transactions même pour des écarts mineurs.

### Question 2:
Quelle stratégie de rotation sectorielle serait la plus appropriée en début de reprise économique après une récession?
- a) Surpondérer les secteurs défensifs comme la santé et les services publics
- b) Surpondérer les secteurs cycliques comme la finance et la consommation discrétionnaire
- c) Maintenir une allocation équilibrée entre tous les secteurs
- d) Surpondérer uniquement les secteurs technologiques

**Réponse correcte: b) Surpondérer les secteurs cycliques comme la finance et la consommation discrétionnaire**

**Explication:** En début de reprise économique, les secteurs cycliques comme la finance et la consommation discrétionnaire tendent à surperformer, car ils bénéficient directement de l'amélioration des conditions économiques, de la baisse du chômage et de l'augmentation des dépenses de consommation.

### Question 3:
Si une action a vu sa pondération passer de 5% à 8% du portefeuille en raison d'une forte performance, quelle approche serait généralement la plus appropriée?
- a) Vendre immédiatement pour revenir à 5%
- b) Ne rien faire car la performance justifie une pondération plus élevée
- c) Évaluer si la hausse est justifiée par les fondamentaux avant de décider
- d) Augmenter encore la position pour capitaliser sur le momentum

**Réponse correcte: c) Évaluer si la hausse est justifiée par les fondamentaux avant de décider**

**Explication:** Avant de rééquilibrer automatiquement, il est important d'évaluer si la surperformance est justifiée par une amélioration des fondamentaux ou des perspectives de l'entreprise. Si c'est le cas, une pondération plus élevée peut être maintenue; sinon, un rééquilibrage partiel ou total peut être approprié.

### Question 4:
Quel élément devrait figurer en priorité dans une fiche d'arbitrage pour un club d'investissement?
- a) L'historique complet du cours de l'action
- b) La justification détaillée de la décision
- c) Les opinions de tous les analystes externes
- d) Les prévisions précises de performance future

**Réponse correcte: b) La justification détaillée de la décision**

**Explication:** La justification détaillée est l'élément le plus important d'une fiche d'arbitrage pour un club d'investissement, car elle permet de documenter le raisonnement collectif, facilite l'évaluation ultérieure de la décision, et assure la transparence du processus décisionnel pour tous les membres.

## Points Clés à Retenir

- Le rééquilibrage périodique est essentiel pour maintenir le profil risque/rendement souhaité du portefeuille.
- Différentes approches de rééquilibrage (calendaire, par seuils, opportuniste) peuvent être combinées pour optimiser le rapport coûts/bénéfices.
- Les signaux déclencheurs de réallocation peuvent être fondamentaux, techniques, macroéconomiques, liés à la valorisation ou à la conviction.
- La rotation sectorielle peut être basée sur le cycle économique, les tendances séculaires ou la valorisation relative.
- La fiche d'arbitrage est un outil pratique pour structurer et documenter les décisions de réallocation au sein du portefeuille.

## Prochaine Section

Dans la section suivante, nous explorerons les outils pratiques qui vous aideront à mettre en œuvre efficacement les concepts et méthodologies présentés dans cette formation, notamment la fiche d'arbitrage simplifiée, la matrice d'allocation interactive et le tableau de bord de suivi.
