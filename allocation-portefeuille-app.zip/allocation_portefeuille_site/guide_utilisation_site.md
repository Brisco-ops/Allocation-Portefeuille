# Guide d'Utilisation du Site Web Interactif
## Formation sur l'Allocation des Lignes d'Actions dans le Portefeuille

Ce guide vous accompagnera dans l'utilisation du site web interactif de formation sur l'allocation des lignes d'actions dans le portefeuille, spécialement conçu pour votre club d'investissement.

## 1. Accès au Site

Le site est accessible à l'adresse suivante : [URL du site déployé]

Vous pouvez y accéder depuis n'importe quel navigateur moderne (Chrome, Firefox, Safari, Edge) sur ordinateur, tablette ou smartphone.

## 2. Structure du Site

Le site est organisé en 6 sections principales, accessibles depuis le menu de navigation en haut de la page ou depuis la barre latérale à gauche :

1. **Les Fondamentaux de l'Allocation** - Principes théoriques essentiels
2. **Stratégies de Diversification** - Différentes dimensions de diversification
3. **Méthodologie d'Allocation** - Approche structurée pour l'allocation optimale
4. **Gestion Dynamique** - Aspect évolutif et rééquilibrage
5. **Outils Pratiques** - Outils concrets pour la mise en œuvre
6. **Bonus - Ressources** - Ressources complémentaires pour approfondir

Chaque section contient :
- Du contenu théorique
- Des exemples concrets
- Des cas pratiques interactifs
- Un quiz pour tester vos connaissances

## 3. Navigation et Progression

### Menu Principal
Le menu principal en haut de la page vous permet d'accéder directement à chaque section.

### Barre Latérale
La barre latérale à gauche offre :
- Un accès rapide à toutes les sections
- Un indicateur visuel des sections déjà complétées (marquées d'une coche verte)
- Un accès direct aux outils interactifs

### Suivi de Progression
- Une barre de progression en haut de la page indique votre avancement global
- Votre progression est automatiquement sauvegardée dans votre navigateur
- Vous pouvez reprendre la formation exactement là où vous l'aviez laissée

## 4. Utilisation des Quiz

Chaque section se termine par un quiz interactif :

1. Cliquez sur le bouton "Passer au Quiz" en bas de la section
2. Répondez aux questions en sélectionnant l'option que vous jugez correcte
3. Après chaque réponse, une explication détaillée s'affiche
4. À la fin du quiz, votre score s'affiche
5. Si vous obtenez au moins 50% de bonnes réponses, la section est marquée comme complétée

## 5. Outils Interactifs

Le site propose trois outils interactifs accessibles depuis la barre latérale ou la page d'outils :

### Matrice d'Allocation
Cet outil vous permet d'évaluer systématiquement les actions selon plusieurs critères pour déterminer leur allocation optimale.

**Utilisation :**
1. Notez chaque action sur les 5 critères (échelle de 1 à 5)
2. Ajustez les pondérations des critères si nécessaire
3. Cliquez sur "Calculer l'allocation" pour voir les résultats
4. Analysez les allocations suggérées

### Fiche d'Arbitrage
Cet outil vous aide à formaliser et documenter vos décisions d'arbitrage entre différentes lignes d'actions.

**Utilisation :**
1. Remplissez les informations sur la ligne à vendre
2. Indiquez les lignes à renforcer
3. Documentez les justifications et l'impact attendu
4. Utilisez cette fiche lors des réunions du club

### Tableau de Bord
Cet outil vous permet de suivre en continu votre allocation et d'identifier rapidement les écarts par rapport à vos cibles.

**Utilisation :**
1. Entrez votre portefeuille actuel
2. Définissez vos allocations cibles
3. Visualisez les écarts et les alertes
4. Utilisez ces informations pour vos décisions de rééquilibrage

## 6. Téléchargement des Ressources

Plusieurs ressources sont disponibles en téléchargement :

- **Outils Excel** : Versions hors ligne des outils interactifs
- **Modèles PowerPoint** : Templates pour vos présentations au comité
- **Documents PDF** : Guides, fiches synthétiques et références

Pour télécharger une ressource :
1. Accédez à la section concernée (généralement section 5 ou 6)
2. Cliquez sur le bouton "Télécharger" à côté de la ressource souhaitée
3. Enregistrez le fichier sur votre ordinateur

## 7. Conseils d'Utilisation

### Pour une Formation Individuelle
- Parcourez les sections dans l'ordre proposé
- Prenez le temps de réfléchir aux cas pratiques
- Testez vos connaissances avec les quiz
- Expérimentez avec les outils interactifs

### Pour une Formation en Groupe
- Utilisez le site comme support lors des réunions du club
- Discutez collectivement des cas pratiques
- Répondez aux quiz en groupe pour stimuler les échanges
- Appliquez les outils à votre portefeuille réel

## 8. Compatibilité et Performances

- Le site est optimisé pour tous les appareils (ordinateurs, tablettes, smartphones)
- Pour une expérience optimale, utilisez un navigateur à jour
- La sauvegarde de progression utilise le stockage local de votre navigateur
- Si vous changez de navigateur ou d'appareil, votre progression ne sera pas transférée

## 9. Support et Assistance

Si vous rencontrez des difficultés ou avez des questions :
- Consultez la section FAQ dans la partie Bonus
- Contactez le support technique à [adresse email]

## 10. Mise à Jour du Contenu

Le contenu du site sera régulièrement mis à jour pour refléter les évolutions des pratiques d'allocation de portefeuille. Nous vous recommandons de revisiter périodiquement la formation pour découvrir les nouveaux contenus et outils.

---

Nous vous souhaitons une excellente expérience de formation et espérons que ce site vous aidera à optimiser l'allocation des lignes d'actions dans votre portefeuille de club d'investissement.
