// Structure des dossiers pour notre application
// /src
// ├── components/
// │   ├── layout/
// │   │   ├── Header.tsx
// │   │   ├── Footer.tsx
// │   │   ├── Sidebar.tsx
// │   │   └── Layout.tsx
// │   ├── ui/
// │   │   ├── Button.tsx
// │   │   ├── Card.tsx
// │   │   ├── ProgressBar.tsx
// │   │   └── ...
// │   ├── quiz/
// │   │   ├── QuizCard.tsx
// │   │   ├── QuizOption.tsx
// │   │   └── QuizResult.tsx
// │   ├── tools/
// │   │   ├── AllocationMatrix.tsx
// │   │   ├── ArbitrageForm.tsx
// │   │   └── DashboardTool.tsx
// │   └── sections/
// │       ├── Section1Fundamentals.tsx
// │       ├── Section2Diversification.tsx
// │       ├── Section3Methodology.tsx
// │       ├── Section4DynamicManagement.tsx
// │       ├── Section5PracticalTools.tsx
// │       └── Section6Bonus.tsx
// ├── hooks/
// │   ├── useProgress.ts
// │   ├── useQuiz.ts
// │   └── useAllocation.ts
// ├── context/
// │   ├── ProgressContext.tsx
// │   └── UserContext.tsx
// ├── data/
// │   ├── quizData.ts
// │   ├── sectionData.ts
// │   └── toolsData.ts
// ├── utils/
// │   ├── formatters.ts
// │   └── calculations.ts
// ├── pages/
// │   ├── HomePage.tsx
// │   ├── SectionPage.tsx
// │   ├── ToolsPage.tsx
// │   └── QuizPage.tsx
// └── assets/
//     ├── images/
//     └── icons/
