import React, { createContext, useState, useContext, ReactNode } from 'react';

interface ProgressContextType {
  completedSections: string[];
  quizScores: Record<string, number>;
  markSectionCompleted: (sectionId: string) => void;
  saveQuizScore: (quizId: string, score: number) => void;
  getProgress: () => number;
}

const defaultContext: ProgressContextType = {
  completedSections: [],
  quizScores: {},
  markSectionCompleted: () => {},
  saveQuizScore: () => {},
  getProgress: () => 0,
};

const ProgressContext = createContext<ProgressContextType>(defaultContext);

export const useProgress = () => useContext(ProgressContext);

interface ProgressProviderProps {
  children: ReactNode;
}

export const ProgressProvider: React.FC<ProgressProviderProps> = ({ children }) => {
  const [completedSections, setCompletedSections] = useState<string[]>(() => {
    const saved = localStorage.getItem('completedSections');
    return saved ? JSON.parse(saved) : [];
  });

  const [quizScores, setQuizScores] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('quizScores');
    return saved ? JSON.parse(saved) : {};
  });

  const markSectionCompleted = (sectionId: string) => {
    if (!completedSections.includes(sectionId)) {
      const updated = [...completedSections, sectionId];
      setCompletedSections(updated);
      localStorage.setItem('completedSections', JSON.stringify(updated));
    }
  };

  const saveQuizScore = (quizId: string, score: number) => {
    const updated = { ...quizScores, [quizId]: score };
    setQuizScores(updated);
    localStorage.setItem('quizScores', JSON.stringify(updated));
  };

  const getProgress = () => {
    // Assuming 6 total sections
    return (completedSections.length / 6) * 100;
  };

  return (
    <ProgressContext.Provider
      value={{
        completedSections,
        quizScores,
        markSectionCompleted,
        saveQuizScore,
        getProgress,
      }}
    >
      {children}
    </ProgressContext.Provider>
  );
};
