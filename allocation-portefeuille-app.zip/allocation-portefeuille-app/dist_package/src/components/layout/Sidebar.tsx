import React from 'react';
import { useProgress } from '../../context/ProgressContext';
import { Link } from 'react-router-dom';

const Sidebar: React.FC = () => {
  const { completedSections } = useProgress();
  
  const sections = [
    { id: '1', title: 'Fondamentaux', icon: '📊' },
    { id: '2', title: 'Diversification', icon: '🔄' },
    { id: '3', title: 'Méthodologie', icon: '📋' },
    { id: '4', title: 'Gestion Dynamique', icon: '⚖️' },
    { id: '5', title: 'Outils Pratiques', icon: '🛠️' },
    { id: '6', title: 'Bonus', icon: '🎁' },
  ];

  return (
    <aside className="w-64 bg-gray-100 p-4 hidden md:block">
      <div className="sticky top-4">
        <h2 className="text-lg font-semibold mb-4">Sections</h2>
        <nav>
          <ul className="space-y-2">
            {sections.map((section) => (
              <li key={section.id}>
                <Link
                  to={`/section/${section.id}`}
                  className={`flex items-center p-2 rounded-lg transition-colors ${
                    completedSections.includes(section.id)
                      ? 'bg-green-100 text-green-800'
                      : 'hover:bg-gray-200'
                  }`}
                >
                  <span className="mr-2">{section.icon}</span>
                  <span>{section.title}</span>
                  {completedSections.includes(section.id) && (
                    <span className="ml-auto">✓</span>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="mt-8">
          <h2 className="text-lg font-semibold mb-4">Outils</h2>
          <ul className="space-y-2">
            <li>
              <Link
                to="/tools/allocation-matrix"
                className="flex items-center p-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <span className="mr-2">📊</span>
                <span>Matrice d'Allocation</span>
              </Link>
            </li>
            <li>
              <Link
                to="/tools/arbitrage-form"
                className="flex items-center p-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <span className="mr-2">📝</span>
                <span>Fiche d'Arbitrage</span>
              </Link>
            </li>
            <li>
              <Link
                to="/tools/dashboard"
                className="flex items-center p-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <span className="mr-2">📈</span>
                <span>Tableau de Bord</span>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
