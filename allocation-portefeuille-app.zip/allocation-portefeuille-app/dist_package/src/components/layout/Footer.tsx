import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h3 className="text-lg font-semibold">Allocation des Lignes d'Actions</h3>
            <p className="text-sm text-blue-200">
              Formation interactive pour clubs d'investissement
            </p>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm">
              © {new Date().getFullYear()} - Tous droits réservés
            </p>
            <p className="text-xs text-blue-200 mt-1">
              Développé pour les clubs d'investissement en actions
            </p>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-blue-800 text-sm text-center">
          <p>
            Cette formation est basée sur des sources fiables et actualisées, mais ne constitue pas un conseil d'investissement personnalisé.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
