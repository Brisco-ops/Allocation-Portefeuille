import React from 'react';
import { Link } from 'react-router-dom';
import { useProgress } from '../../context/ProgressContext';

const Header: React.FC = () => {
  const { getProgress } = useProgress();
  
  return (
    <header className="bg-blue-800 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <Link to="/" className="text-xl font-bold">
            Allocation des Lignes d'Actions
          </Link>
        </div>
        
        <nav className="flex flex-wrap justify-center">
          <Link to="/" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Accueil
          </Link>
          <Link to="/section/1" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Fondamentaux
          </Link>
          <Link to="/section/2" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Diversification
          </Link>
          <Link to="/section/3" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Méthodologie
          </Link>
          <Link to="/section/4" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Gestion Dynamique
          </Link>
          <Link to="/section/5" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Outils Pratiques
          </Link>
          <Link to="/section/6" className="px-3 py-2 rounded hover:bg-blue-700 transition-colors">
            Bonus
          </Link>
        </nav>
        
        <div className="mt-4 md:mt-0 w-full md:w-auto">
          <div className="bg-blue-900 rounded-full h-4 w-full md:w-32 overflow-hidden">
            <div 
              className="bg-green-500 h-full" 
              style={{ width: `${getProgress()}%` }}
            ></div>
          </div>
          <div className="text-xs text-center mt-1">
            Progression: {Math.round(getProgress())}%
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
