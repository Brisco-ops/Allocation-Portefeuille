import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import QuizCard from '../quiz/QuizCard';

interface Section5PracticalToolsProps {
  onComplete: () => void;
}

const Section5PracticalTools: React.FC<Section5PracticalToolsProps> = ({ onComplete }) => {
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  
  const handleQuizComplete = (score: number) => {
    setQuizCompleted(true);
    // Si le score est suffisant, on marque la section comme complétée
    if (score >= 2) { // Au moins 2 bonnes réponses sur 4
      onComplete();
    }
  };

  const content = `
# Outils Pratiques

## Introduction

Bienvenue dans cette cinquième section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Après avoir exploré les aspects théoriques et méthodologiques, nous vous proposons maintenant des outils pratiques prêts à l'emploi pour faciliter la mise en œuvre des principes d'allocation au sein de votre club d'investissement.

Ces outils ont été conçus pour être à la fois rigoureux et faciles à utiliser, vous permettant d'appliquer immédiatement les connaissances acquises dans les sections précédentes. Vous pouvez les télécharger, les adapter à vos besoins spécifiques et les intégrer directement dans vos processus de gestion de portefeuille.

## Fiche d'Arbitrage Simplifiée

### Présentation de l'Outil

La fiche d'arbitrage simplifiée est un document structuré qui vous aide à formaliser et documenter vos décisions d'arbitrage entre différentes lignes d'actions. Elle sert à la fois d'aide à la décision et d'historique pour le suivi des performances.

### Structure et Utilisation

**Structure de la fiche d'arbitrage :**

| Champ | Exemple | Instructions |
|-------|---------|--------------|
| Date de l'arbitrage | 15/06/2025 | Date à laquelle l'arbitrage est effectué |
| Ligne à vendre | Orpéa | Action dont la position doit être réduite ou liquidée |
| Motif de vente | Conviction disparue, chute structurelle | Raison justifiant la vente |
| Valorisation actuelle | NC | Cours actuel et valorisation relative |
| Lignes à renforcer | Air Liquide, Schneider | Actions dont la position doit être augmentée |
| Montant réalloué | 2 000 € | Montant total à réinvestir |
| Justification | Momentum + fondamentaux solides | Raisons justifiant l'achat |
| Effet sur le portefeuille | Réduction du risque + hausse conviction | Impact attendu sur le profil risque/rendement |

**Instructions d'utilisation :**

1. **Préparation :** Remplissez la fiche avant la réunion du club où l'arbitrage sera discuté
2. **Présentation :** Utilisez la fiche comme support de présentation pour expliquer votre proposition
3. **Discussion :** Recueillez les commentaires et ajustez si nécessaire
4. **Décision :** Documentez la décision finale (acceptée, modifiée, rejetée)
5. **Archivage :** Conservez la fiche dans un dossier dédié pour référence future
6. **Suivi :** Évaluez l'efficacité de l'arbitrage lors d'une réunion ultérieure

### Exemples Concrets

**Exemple 1 : Arbitrage pour réduction de risque**
- **Ligne à vendre :** Société Générale (secteur bancaire)
- **Motif :** Exposition excessive au secteur bancaire, risques réglementaires accrus
- **Lignes à renforcer :** Danone, Sanofi
- **Justification :** Diversification vers des secteurs défensifs dans un contexte économique incertain
- **Effet :** Réduction de la volatilité globale du portefeuille

**Exemple 2 : Arbitrage pour saisir une opportunité**
- **Ligne à vendre :** Total Energies
- **Motif :** Prise de bénéfices après forte performance
- **Lignes à renforcer :** ASML
- **Justification :** Opportunité d'achat suite à une correction technique sur un leader sectoriel
- **Effet :** Exposition accrue à un secteur à fort potentiel de croissance

## Matrice d'Allocation Interactive

### Présentation de l'Outil

La matrice d'allocation interactive est un outil Excel qui vous permet d'évaluer systématiquement les actions selon plusieurs critères pour déterminer leur allocation optimale dans le portefeuille.

### Structure et Utilisation

**Structure de la matrice :**

| Colonne | Description | Échelle |
|---------|-------------|---------|
| Action | Nom de l'action | - |
| Secteur | Secteur économique | - |
| Qualité fondamentale | Solidité financière, avantages compétitifs | 1-5 |
| Momentum | Performance récente, tendance, révisions | 1-5 |
| Valorisation | Attractivité des ratios de valorisation | 1-5 |
| Conviction | Niveau de confiance dans l'analyse | 1-5 |
| Fit stratégique | Contribution à la diversification | 1-5 |
| Score total | Somme pondérée des critères | /25 |
| Allocation (%) | Pourcentage calculé du portefeuille | % |

**Instructions d'utilisation :**

1. **Configuration :** Ajustez les pondérations des critères selon vos priorités
2. **Saisie :** Entrez les actions de votre portefeuille et notez-les selon chaque critère
3. **Calcul automatique :** La matrice calcule les scores totaux et les allocations suggérées
4. **Ajustement :** Modifiez les allocations suggérées selon vos contraintes spécifiques
5. **Simulation :** Testez différents scénarios en modifiant les notations ou les pondérations
6. **Décision :** Utilisez les résultats comme base pour vos décisions d'allocation

### Fonctionnalités Avancées

Le modèle Excel inclut plusieurs fonctionnalités avancées :

- **Pondérations personnalisables** pour chaque critère
- **Limites minimales et maximales** par action et par secteur
- **Visualisations graphiques** des allocations actuelles vs suggérées
- **Tableau de diversification** sectorielle et par style
- **Simulation d'impact** des changements d'allocation sur le risque et le rendement attendus
- **Historique des allocations** pour suivre l'évolution dans le temps

## Tableau de Bord de Suivi

### Présentation de l'Outil

Le tableau de bord de suivi est un outil Excel qui vous permet de monitorer en continu votre allocation et d'identifier rapidement les écarts par rapport à vos cibles.

### Structure et Utilisation

**Structure du tableau de bord :**

| Section | Contenu | Utilité |
|---------|---------|---------|
| Allocation par action | Allocation actuelle vs cible, écarts | Identifier les lignes à rééquilibrer |
| Allocation sectorielle | Répartition par secteur, écarts | Surveiller la diversification sectorielle |
| Indicateurs de risque | Volatilité, bêta, drawdown | Évaluer le profil de risque |
| Indicateurs de conviction | % lignes à forte/faible conviction | Identifier les opportunités d'arbitrage |
| Performances | Performance absolue et relative | Évaluer l'efficacité de l'allocation |
| Alertes | Signaux automatiques basés sur seuils | Déclencher des actions |

**Instructions d'utilisation :**

1. **Configuration initiale :** Entrez votre portefeuille et définissez vos allocations cibles
2. **Mise à jour régulière :** Actualisez les cours et les positions à fréquence définie
3. **Analyse des écarts :** Identifiez les écarts significatifs par rapport aux cibles
4. **Suivi des alertes :** Réagissez aux alertes automatiques selon vos règles prédéfinies
5. **Reporting :** Utilisez les graphiques et tableaux pour les présentations au club
6. **Historique :** Conservez un historique des allocations pour analyse rétrospective

### Indicateurs Clés à Suivre

Le tableau de bord met en évidence plusieurs indicateurs clés :

- **% max par ligne** : Limite la concentration sur une seule action (cible recommandée : 10%)
- **% max par secteur** : Assure la diversification sectorielle (cible recommandée : 25%)
- **Nombre de lignes** : Maintient un niveau de diversification optimal (cible recommandée : 15-20)
- **% lignes à forte conviction** : Mesure la confiance dans le portefeuille (cible recommandée : >50%)
- **% lignes à faible conviction** : Identifie les candidats potentiels à l'arbitrage (cible recommandée : <20%)
- **Écart d'allocation** : Mesure la déviation par rapport aux cibles (seuil d'alerte : ±20%)

## Modèles de Présentation pour le Comité

### Présentation de l'Outil

Les modèles de présentation pour le comité sont des templates PowerPoint prêts à l'emploi pour présenter vos analyses et recommandations d'allocation lors des réunions du club.

### Structure et Utilisation

**Modèles disponibles :**

1. **Présentation d'arbitrage** (5-7 slides)
   - Résumé de la proposition
   - Analyse de la ligne à vendre
   - Analyse des lignes à renforcer
   - Impact sur le portefeuille
   - Proposition détaillée et calendrier

2. **Revue trimestrielle d'allocation** (10-12 slides)
   - Synthèse de la performance
   - Analyse de l'allocation actuelle
   - Écarts par rapport aux cibles
   - Évolution du contexte de marché
   - Propositions d'ajustements
   - Calendrier de mise en œuvre

3. **Analyse sectorielle** (8-10 slides)
   - Tendances sectorielles
   - Comparaison des valorisations
   - Opportunités identifiées
   - Risques spécifiques
   - Recommandations d'allocation sectorielle

**Instructions d'utilisation :**

1. **Sélection du modèle** adapté à votre besoin
2. **Personnalisation** avec vos données et analyses
3. **Préparation des messages clés** pour chaque slide
4. **Ajout de visualisations** pertinentes (graphiques, tableaux)
5. **Répétition** de la présentation avant la réunion
6. **Distribution** aux membres avant ou après la réunion selon vos pratiques

### Conseils de Présentation

Pour maximiser l'efficacité de vos présentations au comité :

- **Soyez concis** : Limitez-vous aux informations essentielles
- **Hiérarchisez l'information** : Commencez par les conclusions, puis détaillez
- **Utilisez des visuels** : Un graphique vaut mieux qu'un long discours
- **Anticipez les questions** : Préparez des slides supplémentaires pour y répondre
- **Soyez transparent** sur les incertitudes et les risques
- **Formulez clairement** vos recommandations et les actions attendues

## Intégration des Outils dans votre Processus

### Cycle de Gestion Trimestriel

Voici comment intégrer ces outils dans un cycle de gestion trimestriel typique pour un club d'investissement :

**Semaine 1 : Préparation**
- Mise à jour du tableau de bord de suivi
- Identification des écarts significatifs
- Préparation des fiches d'arbitrage pour les lignes concernées

**Semaine 2 : Analyse**
- Utilisation de la matrice d'allocation pour évaluer les ajustements potentiels
- Analyse approfondie des opportunités identifiées
- Finalisation des propositions d'arbitrage

**Semaine 3 : Décision**
- Présentation au comité avec les modèles PowerPoint
- Discussion et ajustement des propositions
- Décisions collectives sur les arbitrages à effectuer

**Semaine 4 : Exécution**
- Mise en œuvre des décisions d'allocation
- Documentation des transactions
- Mise à jour du tableau de bord avec la nouvelle allocation

### Flux de Travail pour Arbitrages Ponctuels

Pour les arbitrages en dehors du cycle trimestriel :

1. **Identification du besoin** (signal de marché, changement fondamental, etc.)
2. **Préparation rapide** de la fiche d'arbitrage
3. **Circulation** de la proposition aux membres du comité
4. **Décision accélérée** selon les règles prédéfinies
5. **Exécution et documentation**
6. **Intégration** dans le prochain cycle de revue trimestrielle
  `;

  const outilInteractif = `
## Outil Interactif: Simulateur de Matrice d'Allocation

Utilisez ce simulateur pour tester la matrice d'allocation avec vos propres actions et critères. Cet outil vous permet de voir comment différentes notations affectent l'allocation suggérée.

### Instructions:
1. Notez chaque action sur les 5 critères (échelle de 1 à 5)
2. Ajustez les pondérations des critères si nécessaire
3. Visualisez l'allocation suggérée basée sur les scores
4. Testez différents scénarios pour comprendre la sensibilité du modèle
  `;

  const quizQuestions = [
    {
      question: "Quel est l'objectif principal de la fiche d'arbitrage simplifiée?",
      options: [
        "Calculer automatiquement les allocations optimales",
        "Formaliser et documenter les décisions d'arbitrage entre différentes lignes d'actions",
        "Suivre la performance quotidienne du portefeuille",
        "Comparer la performance avec les indices de référence"
      ],
      correctAnswer: 1,
      explanation: "La fiche d'arbitrage simplifiée est un document structuré qui aide à formaliser et documenter les décisions d'arbitrage entre différentes lignes d'actions. Elle sert à la fois d'aide à la décision et d'historique pour le suivi des performances."
    },
    {
      question: "Dans une matrice d'allocation, quel critère évalue généralement la solidité financière et les avantages compétitifs d'une entreprise?",
      options: [
        "Momentum",
        "Valorisation",
        "Qualité fondamentale",
        "Fit stratégique"
      ],
      correctAnswer: 2,
      explanation: "Le critère 'Qualité fondamentale' évalue la solidité financière, les avantages compétitifs et la qualité du management d'une entreprise. C'est un critère essentiel pour évaluer la robustesse à long terme d'un investissement."
    },
    {
      question: "Quelle est la limite maximale recommandée pour l'allocation à une seule ligne d'action dans un portefeuille diversifié?",
      options: [
        "5%",
        "10%",
        "25%",
        "50%"
      ],
      correctAnswer: 1,
      explanation: "Pour un portefeuille diversifié, il est généralement recommandé de limiter l'allocation à une seule ligne d'action à environ 10% maximum. Cette limite aide à réduire le risque spécifique et à maintenir une diversification adéquate."
    },
    {
      question: "Dans un cycle de gestion trimestriel typique pour un club d'investissement, quelle activité est généralement réalisée en premier?",
      options: [
        "Présentation au comité avec les modèles PowerPoint",
        "Mise en œuvre des décisions d'allocation",
        "Mise à jour du tableau de bord de suivi",
        "Utilisation de la matrice d'allocation pour évaluer les ajustements"
      ],
      correctAnswer: 2,
      explanation: "Dans un cycle de gestion trimestriel typique, la première étape (Semaine 1: Préparation) consiste à mettre à jour le tableau de bord de suivi pour identifier les écarts significatifs par rapport aux allocations cibles, avant de procéder aux analyses et décisions."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <ReactMarkdown>{content}</ReactMarkdown>
        
        <div className="mt-8 mb-4">
          <h2 className="text-xl font-semibold mb-4">Outil Interactif: Simulateur de Matrice d'Allocation</h2>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <ReactMarkdown>{outilInteractif}</ReactMarkdown>
            
            <div className="mt-6 bg-white border border-gray-200 rounded-lg p-4">
              <h3 className="font-semibold mb-3">Simulateur de Matrice d'Allocation</h3>
              
              <div className="mb-4">
                <h4 className="font-medium mb-2">Pondération des critères:</h4>
                <div className="grid grid-cols-5 gap-4">
                  {['Qualité', 'Momentum', 'Valorisation', 'Conviction', 'Fit stratégique'].map((critere, index) => (
                    <div key={index} className="flex flex-col">
                      <label className="text-sm mb-1">{critere}</label>
                      <select className="border rounded p-1">
                        {[1, 2, 3, 4, 5].map(n => (
                          <option key={n} value={n}>{n}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left">Action</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Qualité (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Momentum (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Valorisation (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Conviction (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Fit stratégique (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Score total</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Allocation (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      'Air Liquide',
                      'BNP Paribas',
                      'LVMH',
                      'Sanofi',
                      'Dassault Systèmes'
                    ].map((action, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                        <td className="py-2 px-4 border-b border-gray-200">{action}</td>
                        {[...Array(5)].map((_, i) => (
                          <td key={i} className="py-2 px-4 border-b border-gray-200 text-center">
                            <select className="border rounded p-1 w-12">
                              {[1, 2, 3, 4, 5].map(n => (
                                <option key={n} value={n}>{n}</option>
                              ))}
                            </select>
                          </td>
                        ))}
                        <td className="py-2 px-4 border-b border-gray-200 text-center">-</td>
                        <td className="py-2 px-4 border-b border-gray-200 text-center">-</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 text-right">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                  Calculer l'allocation
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 mb-4">
          <h2 className="text-xl font-semibold mb-4">Téléchargement des Outils</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <h3 className="font-semibold mb-2">Fiche d'Arbitrage Simplifiée</h3>
              <p className="text-sm text-gray-600 mb-3">Format Excel et PDF pour documenter vos décisions d'arbitrage</p>
              <button className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm">
                Télécharger
              </button>
            </div>
            
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <h3 className="font-semibold mb-2">Matrice d'Allocation Interactive</h3>
              <p className="text-sm text-gray-600 mb-3">Outil Excel pour évaluer et optimiser l'allocation de votre portefeuille</p>
              <button className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm">
                Télécharger
              </button>
            </div>
            
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <h3 className="font-semibold mb-2">Tableau de Bord de Suivi</h3>
              <p className="text-sm text-gray-600 mb-3">Outil Excel pour monitorer votre allocation et identifier les écarts</p>
              <button className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm">
                Télécharger
              </button>
            </div>
            
            <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <h3 className="font-semibold mb-2">Modèles de Présentation</h3>
              <p className="text-sm text-gray-600 mb-3">Templates PowerPoint pour vos présentations au comité</p>
              <button className="px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm">
                Télécharger
              </button>
            </div>
          </div>
        </div>
        
        {!showQuiz ? (
          <div className="mt-8 text-center">
            <button
              onClick={() => setShowQuiz(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Passer au Quiz
            </button>
          </div>
        ) : (
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Quiz: Outils Pratiques d'Allocation</h2>
            <QuizCard 
              questions={quizQuestions}
              onComplete={handleQuizComplete}
            />
            
            {quizCompleted && (
              <div className="mt-8 text-center">
                <button
                  onClick={onComplete}
                  className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Marquer cette section comme terminée
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Section5PracticalTools;
