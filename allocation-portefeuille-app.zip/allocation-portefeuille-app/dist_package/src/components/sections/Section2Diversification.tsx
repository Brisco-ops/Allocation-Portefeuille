import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import QuizCard from '../quiz/QuizCard';

interface Section2DiversificationProps {
  onComplete: () => void;
}

const Section2Diversification: React.FC<Section2DiversificationProps> = ({ onComplete }) => {
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  
  const handleQuizComplete = (score: number) => {
    setQuizCompleted(true);
    // Si le score est suffisant, on marque la section comme complétée
    if (score >= 2) { // Au moins 2 bonnes réponses sur 4
      onComplete();
    }
  };

  const content = `
# Stratégies de Diversification au sein d'un Portefeuille d'Actions

## Introduction

Bienvenue dans cette deuxième section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Après avoir exploré les fondamentaux de l'allocation, nous allons maintenant nous concentrer sur les différentes stratégies de diversification que vous pouvez mettre en œuvre au sein d'un portefeuille composé uniquement d'actions.

La diversification est souvent résumée par l'adage "ne pas mettre tous ses œufs dans le même panier". Dans le contexte d'un portefeuille d'actions, cela signifie répartir vos investissements entre différentes actions pour réduire le risque global sans nécessairement sacrifier le rendement potentiel.

## Diversification Sectorielle

### Principe et Importance

La diversification sectorielle consiste à répartir vos investissements entre différents secteurs économiques. Chaque secteur réagit différemment aux cycles économiques, aux changements réglementaires et aux innovations technologiques.

Les principaux secteurs économiques incluent :
- Technologie
- Finance
- Santé
- Énergie
- Consommation discrétionnaire
- Consommation de base
- Industrie
- Matériaux
- Services de communication
- Services publics
- Immobilier

### Corrélations Sectorielles

Les actions d'un même secteur ont généralement une forte corrélation entre elles (souvent supérieure à 0,7). C'est pourquoi la diversification entre secteurs est particulièrement efficace pour réduire le risque du portefeuille.

Voici quelques exemples de corrélations typiques entre secteurs :
- **Technologie et Finance** : Corrélation modérée (0,4-0,6)
- **Énergie et Services Publics** : Corrélation élevée (0,6-0,8)
- **Santé et Consommation de Base** : Corrélation faible (0,2-0,4)
- **Technologie et Consommation de Base** : Corrélation très faible (0-0,3)

### Recommandations Pratiques

Pour une diversification sectorielle efficace dans votre club d'investissement :
- Visez une exposition à au moins 5-7 secteurs différents
- Limitez l'exposition à un seul secteur à maximum 25% du portefeuille
- Équilibrez entre secteurs cycliques (technologie, finance, consommation discrétionnaire) et défensifs (santé, services publics, consommation de base)
- Réévaluez régulièrement les allocations sectorielles en fonction des perspectives économiques

## Diversification Géographique

### Principe et Importance

La diversification géographique consiste à investir dans des entreprises opérant sur différents marchés géographiques. Même en se limitant aux actions, il est possible d'obtenir une exposition internationale significative.

Les principales zones géographiques à considérer :
- Europe (France, Allemagne, Royaume-Uni, etc.)
- Amérique du Nord (États-Unis, Canada)
- Asie-Pacifique (Japon, Chine, Australie, etc.)
- Marchés émergents (Inde, Brésil, Afrique du Sud, etc.)

### Avantages de la Diversification Géographique

1. **Réduction du risque pays** : Limite l'exposition aux risques spécifiques à un pays (politiques, réglementaires, économiques)
2. **Exposition à différents cycles économiques** : Les économies ne sont pas parfaitement synchronisées
3. **Accès à des secteurs de croissance** : Certaines régions sont leaders dans des secteurs spécifiques
4. **Protection contre les fluctuations de devises** : À long terme, peut offrir une forme de couverture naturelle

### Approches Pratiques

Pour un club d'investissement français, plusieurs approches sont possibles :
- **Investissement direct** dans des actions étrangères cotées sur des marchés internationaux
- **Investissement dans des multinationales françaises** ayant une forte exposition internationale
- **Investissement dans des entreprises européennes** cotées sur Euronext ou d'autres bourses européennes
- **Attention aux ADR/GDR** (American/Global Depositary Receipts) qui permettent d'investir indirectement dans des entreprises étrangères

### Recommandations Pratiques

- Visez une exposition internationale d'au moins 30-40% du portefeuille
- Commencez par l'Europe et l'Amérique du Nord avant d'explorer les marchés émergents
- Tenez compte des implications fiscales des investissements internationaux
- Considérez la taille et la liquidité des marchés étrangers

## Diversification par Taille de Capitalisation

### Principe et Importance

La diversification par taille de capitalisation consiste à répartir vos investissements entre des entreprises de différentes tailles. On distingue généralement :

- **Large Cap** (Grande capitalisation) : Entreprises valorisées à plus de 10 milliards d'euros
- **Mid Cap** (Moyenne capitalisation) : Entreprises valorisées entre 2 et 10 milliards d'euros
- **Small Cap** (Petite capitalisation) : Entreprises valorisées entre 300 millions et 2 milliards d'euros
- **Micro Cap** (Micro capitalisation) : Entreprises valorisées à moins de 300 millions d'euros

### Caractéristiques par Taille de Capitalisation

| Caractéristique | Large Cap | Mid Cap | Small Cap |
|-----------------|-----------|---------|-----------|
| Volatilité | Plus faible | Moyenne | Plus élevée |
| Liquidité | Élevée | Moyenne | Plus faible |
| Potentiel de croissance | Modéré | Bon | Élevé |
| Risque | Plus faible | Moyen | Plus élevé |
| Information disponible | Abondante | Bonne | Limitée |
| Couverture par analystes | Forte | Moyenne | Faible |

### Recommandations Pratiques

Pour une diversification efficace par taille de capitalisation :
- Maintenez une base solide de Large Caps (60-70% du portefeuille)
- Allouez une portion significative aux Mid Caps (20-30%)
- Limitez l'exposition aux Small Caps (10-15%) en raison de leur volatilité et liquidité plus faible
- Approchez les Micro Caps avec prudence, si vous en incluez

## Diversification par Style d'Investissement

### Principe et Importance

La diversification par style d'investissement consiste à combiner différentes approches d'investissement, principalement :

1. **Value (Valeur)** : Investir dans des entreprises sous-évaluées par rapport à leurs fondamentaux
2. **Growth (Croissance)** : Investir dans des entreprises à forte croissance, souvent à des valorisations plus élevées

### Caractéristiques des Styles d'Investissement

| Caractéristique | Style Value | Style Growth |
|-----------------|-------------|--------------|
| Valorisation | P/E bas, P/B bas | P/E élevé, P/B élevé |
| Croissance | Modérée | Forte |
| Dividendes | Souvent élevés | Souvent faibles ou inexistants |
| Performance cyclique | Surperformance en reprise économique | Surperformance en expansion économique |
| Secteurs typiques | Finance, Énergie, Industrie | Technologie, Santé, Consommation discrétionnaire |
| Horizon d'investissement | Long terme | Moyen à long terme |

### Autres Styles d'Investissement

Au-delà de la dichotomie Value/Growth, d'autres styles peuvent être considérés :
- **Quality (Qualité)** : Entreprises avec des avantages compétitifs durables, une rentabilité élevée et un bilan solide
- **Momentum** : Entreprises dont le prix a récemment surperformé le marché
- **Income (Revenu)** : Entreprises offrant des dividendes élevés et stables
- **GARP (Growth At Reasonable Price)** : Approche hybride visant des entreprises en croissance à des prix raisonnables

### Recommandations Pratiques

Pour une diversification efficace par style :
- Équilibrez votre portefeuille entre Value et Growth (par exemple, 40-60% ou 60-40%)
- Adaptez l'allocation entre styles en fonction du cycle économique
- Considérez l'inclusion d'approches hybrides comme GARP ou Quality
- Réévaluez régulièrement la performance relative des différents styles
  `;

  const casePratique = `
## Cas Pratique: Diagnostic d'un Portefeuille Déséquilibré

### Présentation du Portefeuille Fictif

Voici la composition actuelle du portefeuille du Club d'Investissement XYZ :

| Action | Secteur | Capitalisation | Style | Région | Allocation (%) |
|--------|---------|---------------|-------|--------|---------------|
| LVMH | Consommation discrétionnaire | Large Cap | Growth | Europe | 15% |
| L'Oréal | Consommation discrétionnaire | Large Cap | Growth | Europe | 12% |
| Kering | Consommation discrétionnaire | Large Cap | Growth | Europe | 10% |
| Hermès | Consommation discrétionnaire | Large Cap | Growth | Europe | 8% |
| BNP Paribas | Finance | Large Cap | Value | Europe | 7% |
| Société Générale | Finance | Large Cap | Value | Europe | 6% |
| Crédit Agricole | Finance | Large Cap | Value | Europe | 5% |
| Total Energies | Énergie | Large Cap | Value | Europe | 10% |
| Engie | Services publics | Large Cap | Value | Europe | 5% |
| Sanofi | Santé | Large Cap | Value | Europe | 8% |
| Dassault Systèmes | Technologie | Large Cap | Growth | Europe | 7% |
| Capgemini | Technologie | Mid Cap | Growth | Europe | 7% |

### Identification des Déséquilibres

Analysez ce portefeuille et identifiez les principaux déséquilibres en termes de :
1. Diversification sectorielle
2. Diversification géographique
3. Diversification par taille de capitalisation
4. Diversification par style d'investissement

### Propositions d'Ajustements

Proposez des ajustements pour rééquilibrer ce portefeuille en :
1. Réduisant certaines positions surpondérées
2. Ajoutant de nouvelles positions dans des secteurs/régions/styles sous-représentés
3. Maintenant un nombre raisonnable de lignes (15-20)
  `;

  const quizQuestions = [
    {
      question: "Quelle est la limite maximale recommandée d'exposition à un seul secteur dans un portefeuille d'actions?",
      options: [
        "10%",
        "25%",
        "40%",
        "50%"
      ],
      correctAnswer: 1,
      explanation: "Il est généralement recommandé de limiter l'exposition à un seul secteur à maximum 25% du portefeuille pour éviter une concentration excessive et maintenir une diversification sectorielle adéquate."
    },
    {
      question: "Quelle est la principale raison de diversifier géographiquement un portefeuille d'actions?",
      options: [
        "Augmenter le rendement global",
        "Réduire les frais de gestion",
        "Réduire le risque pays et l'exposition aux cycles économiques locaux",
        "Simplifier la gestion du portefeuille"
      ],
      correctAnswer: 2,
      explanation: "La diversification géographique permet principalement de réduire le risque pays (risques politiques, réglementaires, économiques) et d'obtenir une exposition à différents cycles économiques qui ne sont pas parfaitement synchronisés."
    },
    {
      question: "Quelle répartition par taille de capitalisation est généralement recommandée pour un portefeuille d'actions équilibré?",
      options: [
        "100% Large Caps",
        "50% Large Caps, 50% Small Caps",
        "60-70% Large Caps, 20-30% Mid Caps, 10-15% Small Caps",
        "33% Large Caps, 33% Mid Caps, 33% Small Caps"
      ],
      correctAnswer: 2,
      explanation: "Une répartition équilibrée typique consiste à maintenir une base solide de Large Caps (60-70%), une portion significative de Mid Caps (20-30%) et une exposition limitée aux Small Caps (10-15%) en raison de leur volatilité et liquidité plus faible."
    },
    {
      question: "Dans quel contexte économique les actions de style 'Value' ont-elles tendance à surperformer?",
      options: [
        "En période d'expansion économique rapide",
        "En période de reprise économique après une récession",
        "En période de forte inflation",
        "En période de récession"
      ],
      correctAnswer: 1,
      explanation: "Les actions de style 'Value' ont généralement tendance à surperformer en période de reprise économique après une récession, lorsque les valorisations basses commencent à se normaliser et que les secteurs cycliques (où l'on trouve souvent des actions Value) bénéficient de l'amélioration des conditions économiques."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <ReactMarkdown>{content}</ReactMarkdown>
        
        <div className="mt-8 mb-4">
          <h2 className="text-xl font-semibold mb-4">Cas Pratique Interactif</h2>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
            <ReactMarkdown>{casePratique}</ReactMarkdown>
            
            <div className="mt-6 p-4 bg-white border border-gray-200 rounded-lg">
              <h3 className="font-semibold mb-3">Votre analyse:</h3>
              <textarea 
                className="w-full p-3 border border-gray-300 rounded-md h-32"
                placeholder="Notez ici votre analyse des déséquilibres et vos propositions d'ajustements..."
              ></textarea>
              
              <div className="mt-4 text-right">
                <button className="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition-colors">
                  Vérifier mon analyse
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {!showQuiz ? (
          <div className="mt-8 text-center">
            <button
              onClick={() => setShowQuiz(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Passer au Quiz
            </button>
          </div>
        ) : (
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Quiz: Stratégies de Diversification</h2>
            <QuizCard 
              questions={quizQuestions}
              onComplete={handleQuizComplete}
            />
            
            {quizCompleted && (
              <div className="mt-8 text-center">
                <button
                  onClick={onComplete}
                  className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Marquer cette section comme terminée
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Section2Diversification;
