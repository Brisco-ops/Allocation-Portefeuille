import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import QuizCard from '../quiz/QuizCard';

interface Section4DynamicManagementProps {
  onComplete: () => void;
}

const Section4DynamicManagement: React.FC<Section4DynamicManagementProps> = ({ onComplete }) => {
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  
  const handleQuizComplete = (score: number) => {
    setQuizCompleted(true);
    // Si le score est suffisant, on marque la section comme complétée
    if (score >= 2) { // Au moins 2 bonnes réponses sur 4
      onComplete();
    }
  };

  const content = `
# Gestion Dynamique de l'Allocation

## Introduction

Bienvenue dans cette quatrième section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Après avoir exploré les fondamentaux, les stratégies de diversification et les méthodologies d'allocation, nous allons maintenant nous concentrer sur l'aspect dynamique de l'allocation et l'importance des ajustements périodiques.

L'allocation de portefeuille n'est pas un exercice statique mais un processus continu qui nécessite des ajustements réguliers pour s'adapter à l'évolution des marchés, des entreprises et de vos objectifs. Cette section vous présentera les principes et les techniques de gestion dynamique de l'allocation pour optimiser la performance de votre portefeuille d'actions sur le long terme.

## Principes du Rééquilibrage de Portefeuille

### Définition et Objectifs du Rééquilibrage

Le rééquilibrage de portefeuille est le processus qui consiste à ajuster périodiquement les pondérations des différentes lignes d'actions pour les ramener à leur allocation cible. C'est un élément essentiel de la gestion de portefeuille qui permet de :

1. **Maintenir le profil risque/rendement souhaité** : Sans rééquilibrage, les pondérations dérivent naturellement en fonction des performances relatives, modifiant progressivement le profil de risque du portefeuille.

2. **Appliquer une discipline d'investissement** : Le rééquilibrage force à "vendre haut et acheter bas", en réduisant les positions qui ont surperformé et en renforçant celles qui ont sous-performé.

3. **Capturer la prime de diversification** : En maintenant une diversification optimale, le rééquilibrage permet de bénéficier des avantages de la diversification sur le long terme.

4. **Adapter le portefeuille à l'évolution du contexte** : Le rééquilibrage permet d'ajuster l'allocation en fonction des changements dans l'environnement économique, les perspectives sectorielles ou la situation des entreprises.

### Types de Rééquilibrage

#### Rééquilibrage Calendaire

Le rééquilibrage calendaire consiste à ajuster les pondérations à intervalles réguliers prédéfinis.

**Fréquences typiques :**
- **Mensuelle** : Très active, adaptée aux portefeuilles très volatils ou en période de forte volatilité
- **Trimestrielle** : Équilibre entre réactivité et coûts de transaction, souvent privilégiée par les clubs d'investissement
- **Semestrielle** : Moins de transactions, adaptée aux portefeuilles plus stables
- **Annuelle** : Minimise les coûts de transaction, mais peut laisser les allocations dériver significativement entre deux rééquilibrages

**Avantages :**
- Simplicité de mise en œuvre
- Discipline d'investissement
- Planification facilitée des réunions du club

**Inconvénients :**
- Ne tient pas compte des conditions de marché
- Peut entraîner des transactions inutiles si les écarts sont faibles
- Peut manquer d'opportunités de rééquilibrage entre deux dates

#### Rééquilibrage par Seuils

Le rééquilibrage par seuils consiste à ajuster les pondérations lorsqu'elles s'écartent d'un certain pourcentage par rapport à leur allocation cible.

**Exemples de seuils :**
- **Seuils relatifs** : Rééquilibrer lorsqu'une position s'écarte de ±20% de son allocation cible (ex: une position cible de 10% est rééquilibrée si elle atteint 8% ou 12%)
- **Seuils absolus** : Rééquilibrer lorsqu'une position s'écarte de ±2 points de pourcentage de son allocation cible (ex: une position cible de 10% est rééquilibrée si elle atteint 8% ou 12%)
- **Seuils combinés** : Utiliser à la fois des seuils relatifs et absolus, en appliquant celui qui est atteint en premier

**Avantages :**
- Rééquilibrage uniquement lorsque nécessaire
- Réduction des coûts de transaction
- Adaptation à la volatilité du marché

**Inconvénients :**
- Suivi plus complexe
- Peut entraîner des rééquilibrages fréquents en période de forte volatilité
- Nécessite une surveillance continue

#### Rééquilibrage Hybride

Le rééquilibrage hybride combine les approches calendaire et par seuils.

**Exemple :**
- Vérifier les allocations trimestriellement
- Rééquilibrer uniquement si les écarts dépassent les seuils définis

**Avantages :**
- Combine les avantages des deux approches
- Équilibre entre discipline et flexibilité
- Bien adapté aux clubs d'investissement

**Inconvénients :**
- Plus complexe à mettre en œuvre
- Nécessite de définir à la fois une fréquence et des seuils

### Considérations Pratiques pour le Rééquilibrage

#### Coûts de Transaction

Les coûts de transaction peuvent éroder les bénéfices du rééquilibrage et doivent être pris en compte dans la stratégie.

**Recommandations :**
- Éviter les rééquilibrages trop fréquents pour des écarts mineurs
- Utiliser les flux de trésorerie (nouveaux apports, dividendes) pour rééquilibrer partiellement
- Considérer des seuils plus larges pour les positions à faible pondération

#### Implications Fiscales

Pour les clubs d'investissement, les implications fiscales des plus-values réalisées lors des rééquilibrages doivent être considérées.

**Recommandations :**
- Tenir compte du traitement fiscal des plus-values à court terme vs long terme
- Privilégier, lorsque possible, la vente de positions en moins-value pour compenser les plus-values
- Considérer le timing des rééquilibrages par rapport à la fin de l'année fiscale

#### Biais Comportementaux

Les biais comportementaux peuvent interférer avec la discipline de rééquilibrage.

**Biais courants :**
- **Aversion à la perte** : Réticence à vendre des positions perdantes
- **Effet de disposition** : Tendance à vendre trop tôt les gagnants et à conserver trop longtemps les perdants
- **Biais de récence** : Surpondération des performances récentes dans les décisions

**Recommandations :**
- Établir un processus de rééquilibrage systématique et documenté
- Discuter ouvertement des biais potentiels lors des réunions du club
- Utiliser des outils objectifs pour guider les décisions de rééquilibrage

## Stratégies d'Arbitrage entre Lignes d'Actions

### Définition et Objectifs de l'Arbitrage

L'arbitrage entre lignes d'actions consiste à vendre certaines positions pour en renforcer d'autres, indépendamment du rééquilibrage régulier. Contrairement au rééquilibrage qui vise à maintenir une allocation cible, l'arbitrage vise à modifier activement l'allocation pour saisir des opportunités ou réduire des risques spécifiques.

**Objectifs de l'arbitrage :**
- Saisir des opportunités d'investissement attractives
- Réduire l'exposition à des risques identifiés
- Améliorer le profil rendement/risque global du portefeuille
- Adapter le portefeuille à un changement de perspective

### Types d'Arbitrages

#### Arbitrage Fondamental

L'arbitrage fondamental est basé sur l'analyse des fondamentaux des entreprises et vise à remplacer des actions dont les perspectives se dégradent par des actions aux perspectives plus favorables.

**Déclencheurs typiques :**
- Détérioration des résultats financiers
- Changements dans l'environnement concurrentiel
- Problèmes de gouvernance ou de management
- Nouvelles opportunités d'investissement identifiées

**Exemple :**
Vendre une action bancaire dont les marges sont sous pression pour renforcer une action technologique bénéficiant d'une croissance structurelle.

#### Arbitrage Sectoriel

L'arbitrage sectoriel consiste à modifier l'allocation entre différents secteurs en fonction des perspectives économiques et sectorielles.

**Déclencheurs typiques :**
- Changement de phase dans le cycle économique
- Évolutions réglementaires affectant certains secteurs
- Innovations technologiques disruptives
- Changements dans les tendances de consommation

**Exemple :**
Réduire l'exposition au secteur de la consommation discrétionnaire en anticipation d'un ralentissement économique pour renforcer des secteurs défensifs comme la santé ou les services publics.

#### Arbitrage Tactique

L'arbitrage tactique vise à exploiter des opportunités à court ou moyen terme liées à des événements spécifiques ou des inefficiences de marché.

**Déclencheurs typiques :**
- Réactions excessives du marché à des événements
- Opérations sur capital (fusions, acquisitions, scissions)
- Entrée ou sortie d'indices
- Changements réglementaires spécifiques

**Exemple :**
Renforcer une position dans une entreprise temporairement affectée par un événement négatif mais dont les fondamentaux restent solides.

### Processus de Décision pour les Arbitrages

#### Étapes Clés du Processus

1. **Identification de l'opportunité ou du risque**
   - Analyse fondamentale, technique ou macroéconomique
   - Veille sectorielle et concurrentielle
   - Suivi des événements de marché

2. **Analyse comparative**
   - Comparaison des positions à vendre et à renforcer
   - Évaluation de l'impact sur le profil risque/rendement du portefeuille
   - Analyse des corrélations et de la diversification

3. **Proposition d'arbitrage**
   - Documentation de l'analyse et de la justification
   - Quantification des montants à arbitrer
   - Évaluation des coûts de transaction et implications fiscales

4. **Décision collective**
   - Présentation au comité d'investissement ou au club
   - Discussion et ajustements éventuels
   - Vote si nécessaire

5. **Exécution et suivi**
   - Mise en œuvre de l'arbitrage
   - Documentation des transactions
   - Suivi de la performance post-arbitrage

#### Fiche d'Arbitrage Standardisée

Pour faciliter et structurer les décisions d'arbitrage, il est recommandé d'utiliser une fiche d'arbitrage standardisée qui inclut :

- **Date et auteur** de la proposition
- **Positions à réduire/vendre** avec justification
- **Positions à renforcer/acheter** avec justification
- **Montants concernés** et impact sur l'allocation globale
- **Analyse d'impact** sur le profil risque/rendement du portefeuille
- **Horizon temporel** de l'arbitrage (tactique ou stratégique)
- **Critères de succès** pour évaluer ultérieurement la pertinence de la décision

## Adaptation de l'Allocation aux Changements de Marché

### Identification des Régimes de Marché

Les régimes de marché sont des périodes caractérisées par des comportements spécifiques des marchés financiers. Identifier le régime actuel et anticiper les transitions peut aider à optimiser l'allocation.

**Principaux régimes de marché :**

1. **Expansion** : Croissance économique forte, inflation modérée, hausse des marchés
   - Favorable aux secteurs cycliques (technologie, consommation discrétionnaire, industrie)
   - Favorable aux small et mid caps
   - Favorable au style growth

2. **Surchauffe** : Croissance économique forte, inflation en hausse, volatilité accrue
   - Favorable aux secteurs liés aux matières premières et à l'énergie
   - Favorable aux entreprises avec un pricing power
   - Attention particulière à la valorisation

3. **Ralentissement** : Croissance économique en baisse, inflation variable, marchés instables
   - Favorable aux secteurs défensifs (santé, consommation de base, services publics)
   - Favorable aux large caps
   - Transition progressive vers le style value

4. **Contraction** : Croissance économique négative, déflation possible, baisse des marchés
   - Favorable aux secteurs très défensifs et aux dividendes stables
   - Favorable aux entreprises avec bilan solide et faible endettement
   - Opportunités sélectives dans les valeurs de qualité fortement corrigées

### Indicateurs Avancés de Changement de Régime

Plusieurs indicateurs peuvent aider à anticiper les changements de régime de marché :

1. **Indicateurs économiques** :
   - Courbe des taux (inversion potentiellement annonciatrice de récession)
   - Indices PMI (indicateurs avancés de l'activité manufacturière et des services)
   - Taux de chômage et créations d'emplois
   - Confiance des consommateurs et des entreprises

2. **Indicateurs de marché** :
   - Volatilité implicite (VIX)
   - Écarts de crédit (spreads)
   - Rotation sectorielle
   - Breadth market (largeur du marché)

3. **Indicateurs techniques** :
   - Moyennes mobiles
   - Momentum
   - Volumes
   - Divergences prix/indicateurs

### Stratégies d'Adaptation

#### Adaptation Progressive

L'adaptation progressive consiste à ajuster graduellement l'allocation en fonction des signaux de changement de régime.

**Avantages :**
- Réduit le risque de timing incorrect
- Limite l'impact des faux signaux
- Permet d'observer la confirmation des tendances

**Mise en œuvre :**
- Définir des seuils de déclenchement pour les indicateurs suivis
- Planifier des ajustements par étapes (ex: 25% de l'ajustement total à chaque étape)
- Documenter le processus et les critères de décision

#### Allocation Tactique vs Stratégique

Il est important de distinguer les ajustements tactiques (court terme) des changements stratégiques (long terme) dans l'allocation.

**Allocation stratégique :**
- Basée sur les objectifs à long terme et la tolérance au risque
- Modifiée uniquement en cas de changements structurels ou d'évolution des objectifs
- Sert de référence pour évaluer les écarts tactiques

**Allocation tactique :**
- Ajustements temporaires par rapport à l'allocation stratégique
- Basée sur les perspectives à court/moyen terme
- Limitée à des écarts définis par rapport à l'allocation stratégique (ex: ±5% par secteur)

**Recommandation :**
Définir clairement les limites des ajustements tactiques autorisés par rapport à l'allocation stratégique pour maintenir la discipline d'investissement tout en permettant une certaine flexibilité.

## Évaluation de l'Efficacité de l'Allocation

### Mesures de Performance

Pour évaluer l'efficacité de votre stratégie d'allocation, plusieurs mesures de performance doivent être suivies régulièrement :

1. **Performance absolue** :
   - Rendement total (incluant dividendes)
   - Rendement annualisé
   - Rendement cumulé depuis l'origine

2. **Performance relative** :
   - Comparaison avec un indice de référence approprié
   - Comparaison avec des portefeuilles similaires
   - Alpha (surperformance ajustée du risque)

3. **Mesures ajustées du risque** :
   - Ratio de Sharpe (rendement excédentaire par unité de risque)
   - Ratio de Sortino (rendement excédentaire par unité de risque baissier)
   - Maximum drawdown (baisse maximale)

### Attribution de Performance

L'attribution de performance permet de comprendre les sources de la performance et d'identifier les forces et faiblesses de votre stratégie d'allocation.

**Principales composantes :**

1. **Allocation sectorielle** : Impact des choix de pondération entre secteurs
2. **Sélection de titres** : Impact des choix spécifiques d'actions au sein de chaque secteur
3. **Effet d'interaction** : Impact combiné de l'allocation sectorielle et de la sélection de titres

**Exemple d'analyse :**
- Surpondération du secteur technologique : +1,2% de contribution
- Sélection d'actions dans le secteur financier : -0,5% de contribution
- Sous-pondération du secteur énergétique : -0,8% de contribution
- Performance totale relative : -0,1% vs indice de référence

### Ajustement de la Stratégie

Sur la base de l'évaluation de performance, des ajustements peuvent être nécessaires dans votre stratégie d'allocation :

1. **Révision des critères de sélection** :
   - Renforcer les critères qui ont bien fonctionné
   - Modifier ou abandonner ceux qui ont systématiquement sous-performé
   - Ajouter de nouveaux critères pertinents

2. **Ajustement du processus de décision** :
   - Améliorer la collecte et l'analyse des informations
   - Renforcer la discipline d'investissement
   - Réduire l'impact des biais comportementaux

3. **Modification des règles d'allocation** :
   - Ajuster les limites de concentration
   - Revoir la fréquence ou les seuils de rééquilibrage
   - Adapter les règles aux conditions de marché actuelles

**Recommandation :**
Conduire une revue approfondie de la stratégie d'allocation au moins annuellement, en documentant les leçons apprises et les ajustements décidés.
  `;

  const casePratique = `
## Cas Pratique: Décision d'Arbitrage

### Contexte

Le Club d'Investissement XYZ dispose d'un portefeuille de 20 lignes d'actions avec une allocation sectorielle relativement équilibrée. Lors de la dernière réunion, un membre a proposé un arbitrage entre plusieurs positions.

### Proposition d'Arbitrage

**Positions à réduire/vendre :**
1. **Orpéa** (Santé - EHPAD) - Vente totale de la position (3% du portefeuille)
   - Justification: Scandale sur la qualité des soins, risques réglementaires accrus, gouvernance défaillante
   - Cours actuel: En forte baisse (-70% sur 1 an)
   - Perspective: Incertitude sur le modèle économique à long terme

**Positions à renforcer/acheter :**
1. **Air Liquide** (Matériaux - Gaz industriels) - Renforcement (+1,5% du portefeuille)
   - Justification: Position solide sur le marché de l'hydrogène, dividendes stables et croissants, résilience en période d'inflation
   - Valorisation: Légèrement au-dessus de la moyenne historique mais justifiée par les perspectives
   - Fit stratégique: Renforcement du caractère défensif du portefeuille

2. **Schneider Electric** (Industrie - Gestion de l'énergie) - Renforcement (+1,5% du portefeuille)
   - Justification: Exposition à la transition énergétique, leadership dans l'efficacité énergétique, croissance internationale
   - Momentum: Solide, avec des révisions à la hausse des estimations de bénéfices
   - Fit stratégique: Exposition à une tendance structurelle de long terme

### Analyse d'Impact

**Impact sur l'allocation sectorielle :**
- Réduction de l'exposition au secteur de la santé (-3%)
- Augmentation de l'exposition aux matériaux (+1,5%) et à l'industrie (+1,5%)
- Maintien d'une diversification sectorielle adéquate

**Impact sur le profil risque/rendement :**
- Réduction du risque spécifique lié à Orpéa
- Augmentation de la qualité globale du portefeuille
- Légère augmentation de l'exposition cyclique, compensée par la nature défensive d'Air Liquide

### Votre Décision

En tant que membre du comité d'investissement, vous devez analyser cette proposition et prendre une décision. Considérez les éléments suivants :

1. La pertinence des justifications fournies
2. L'impact sur la diversification du portefeuille
3. Le timing de l'arbitrage (vendre après une forte baisse?)
4. Les alternatives possibles (autres actions à renforcer?)
5. Les implications pour la stratégie globale du club
  `;

  const quizQuestions = [
    {
      question: "Quelle est la principale différence entre le rééquilibrage et l'arbitrage dans la gestion d'un portefeuille d'actions?",
      options: [
        "Le rééquilibrage concerne uniquement les grandes capitalisations, l'arbitrage les petites",
        "Le rééquilibrage vise à maintenir l'allocation cible, l'arbitrage à modifier activement l'allocation",
        "Le rééquilibrage est trimestriel, l'arbitrage est annuel",
        "Le rééquilibrage est automatique, l'arbitrage nécessite toujours une décision humaine"
      ],
      correctAnswer: 1,
      explanation: "Le rééquilibrage est un processus qui vise à ramener les pondérations du portefeuille à leur allocation cible initiale, tandis que l'arbitrage vise à modifier activement l'allocation pour saisir des opportunités ou réduire des risques spécifiques identifiés."
    },
    {
      question: "Quelle approche de rééquilibrage est généralement la plus adaptée pour un club d'investissement?",
      options: [
        "Rééquilibrage quotidien",
        "Rééquilibrage calendaire mensuel",
        "Rééquilibrage hybride (calendaire avec seuils)",
        "Absence de rééquilibrage"
      ],
      correctAnswer: 2,
      explanation: "L'approche hybride, combinant une vérification calendaire (souvent trimestrielle) avec des seuils de déclenchement, est généralement la plus adaptée pour un club d'investissement. Elle permet de maintenir une discipline tout en évitant des transactions inutiles pour des écarts mineurs, et s'adapte bien au rythme de réunion typique d'un club."
    },
    {
      question: "Lors d'un ralentissement économique, quels secteurs sont généralement favorisés dans l'allocation?",
      options: [
        "Technologie et consommation discrétionnaire",
        "Énergie et matériaux",
        "Santé, consommation de base et services publics",
        "Banques et assurances"
      ],
      correctAnswer: 2,
      explanation: "En période de ralentissement économique, les secteurs défensifs comme la santé, la consommation de base et les services publics sont généralement favorisés car ils offrent une plus grande stabilité des revenus et des bénéfices, étant moins sensibles aux cycles économiques."
    },
    {
      question: "Quelle mesure est la plus pertinente pour évaluer la performance d'un portefeuille en tenant compte du risque pris?",
      options: [
        "Rendement total",
        "Alpha",
        "Ratio de Sharpe",
        "Maximum drawdown"
      ],
      correctAnswer: 2,
      explanation: "Le ratio de Sharpe mesure le rendement excédentaire (par rapport au taux sans risque) par unité de risque (volatilité). C'est une mesure particulièrement pertinente car elle permet de comparer des portefeuilles avec des niveaux de risque différents en évaluant l'efficience de la prise de risque."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <ReactMarkdown>{content}</ReactMarkdown>
        
        <div className="mt-8 mb-4">
          <h2 className="text-xl font-semibold mb-4">Cas Pratique: Décision d'Arbitrage</h2>
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <ReactMarkdown>{casePratique}</ReactMarkdown>
            
            <div className="mt-6 p-4 bg-white border border-gray-200 rounded-lg">
              <h3 className="font-semibold mb-3">Votre analyse et décision:</h3>
              <textarea 
                className="w-full p-3 border border-gray-300 rounded-md h-32"
                placeholder="Notez ici votre analyse de la proposition d'arbitrage et votre décision..."
              ></textarea>
              
              <div className="mt-4 text-right">
                <button className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  Soumettre ma décision
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {!showQuiz ? (
          <div className="mt-8 text-center">
            <button
              onClick={() => setShowQuiz(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Passer au Quiz
            </button>
          </div>
        ) : (
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Quiz: Gestion Dynamique de l'Allocation</h2>
            <QuizCard 
              questions={quizQuestions}
              onComplete={handleQuizComplete}
            />
            
            {quizCompleted && (
              <div className="mt-8 text-center">
                <button
                  onClick={onComplete}
                  className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Marquer cette section comme terminée
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Section4DynamicManagement;
