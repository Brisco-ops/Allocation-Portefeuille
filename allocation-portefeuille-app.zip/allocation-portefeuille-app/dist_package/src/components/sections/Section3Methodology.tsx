import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import QuizCard from '../quiz/QuizCard';

interface Section3MethodologyProps {
  onComplete: () => void;
}

const Section3Methodology: React.FC<Section3MethodologyProps> = ({ onComplete }) => {
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  
  const handleQuizComplete = (score: number) => {
    setQuizCompleted(true);
    // Si le score est suffisant, on marque la section comme complétée
    if (score >= 2) { // Au moins 2 bonnes réponses sur 4
      onComplete();
    }
  };

  const content = `
# Méthodologie d'Allocation pour un Club d'Investissement en Actions

## Introduction

Bienvenue dans cette troisième section de notre formation sur l'allocation des lignes d'actions dans le portefeuille. Après avoir exploré les fondamentaux de l'allocation et les stratégies de diversification, nous allons maintenant nous concentrer sur les méthodologies concrètes d'allocation pour votre club d'investissement.

Cette section vous présentera des approches structurées pour déterminer l'allocation optimale entre différentes lignes d'actions, en tenant compte des spécificités d'un club d'investissement qui se concentre exclusivement sur les actions.

## Les Différentes Stratégies d'Allocation

### Stratégie Active

La stratégie d'allocation active implique des ajustements fréquents du portefeuille en fonction de l'analyse des marchés, des secteurs et des entreprises individuelles.

**Caractéristiques principales :**
- Ajustements fréquents des pondérations
- Analyse approfondie des opportunités d'investissement
- Transactions régulières pour maximiser les rendements
- Suivi constant des positions et du marché

**Avantages :**
- Potentiel de surperformance par rapport au marché
- Capacité à s'adapter rapidement aux changements de conditions
- Possibilité de capitaliser sur des opportunités à court terme

**Inconvénients :**
- Coûts de transaction plus élevés
- Risque de timing de marché incorrect
- Nécessite plus de temps et d'expertise
- Peut générer plus d'erreurs dues aux biais comportementaux

**Application dans un club d'investissement :**
Pour un club d'investissement, la stratégie active peut être mise en œuvre collectivement, avec des décisions prises lors des réunions régulières. Cela nécessite un processus de décision bien structuré et une répartition claire des responsabilités d'analyse entre les membres.

### Stratégie Passive

La stratégie d'allocation passive implique une approche plus stable avec des ajustements moins fréquents du portefeuille.

**Caractéristiques principales :**
- Ajustements limités des pondérations
- Focus sur la construction initiale d'un portefeuille équilibré
- Rééquilibrages périodiques plutôt que réactions aux mouvements de marché
- Horizon d'investissement plus long

**Avantages :**
- Coûts de transaction réduits
- Moins de temps consacré à l'analyse et au suivi
- Moins susceptible aux erreurs dues aux biais comportementaux
- Simplicité de mise en œuvre

**Inconvénients :**
- Potentiel limité de surperformance
- Exposition continue aux secteurs ou actions en difficulté
- Peut manquer d'opportunités à court terme

**Application dans un club d'investissement :**
La stratégie passive peut être particulièrement adaptée aux clubs d'investissement avec des membres ayant des disponibilités limitées. Elle permet de concentrer les efforts sur la sélection initiale des actions et les rééquilibrages périodiques plutôt que sur des ajustements constants.

### Stratégie Discrétionnaire

La stratégie d'allocation discrétionnaire repose sur les décisions d'un ou plusieurs gestionnaires qui ont le pouvoir de prendre des décisions d'investissement selon leur jugement.

**Caractéristiques principales :**
- Décisions basées sur l'expertise et le jugement des gestionnaires
- Flexibilité dans l'approche d'investissement
- Combinaison possible d'analyses quantitatives et qualitatives
- Adaptation aux conditions de marché selon l'interprétation des gestionnaires

**Avantages :**
- Flexibilité maximale
- Capacité à intégrer des facteurs qualitatifs difficiles à quantifier
- Peut s'adapter rapidement aux changements de conditions

**Inconvénients :**
- Dépendance forte envers les compétences des décideurs
- Risque de biais comportementaux
- Peut manquer de cohérence dans le temps
- Difficile à évaluer objectivement

**Application dans un club d'investissement :**
Dans un club, cette approche peut être mise en œuvre en désignant un comité d'investissement restreint qui dispose d'une certaine latitude pour prendre des décisions entre les réunions plénières, dans un cadre prédéfini par l'ensemble des membres.

### Stratégie Stratégique

La stratégie d'allocation stratégique vise à aligner le portefeuille avec les objectifs à long terme, en définissant des allocations cibles qui sont maintenues sur de longues périodes.

**Caractéristiques principales :**
- Définition d'allocations cibles à long terme
- Rééquilibrages périodiques pour revenir aux allocations cibles
- Focus sur les objectifs à long terme plutôt que les opportunités à court terme
- Approche disciplinée et systématique

**Avantages :**
- Cohérence dans le temps
- Discipline d'investissement
- Réduction des erreurs dues aux réactions émotionnelles
- Simplicité relative de mise en œuvre

**Inconvénients :**
- Manque de flexibilité face aux changements structurels
- Peut sous-performer dans certaines conditions de marché
- Nécessite une définition précise des allocations cibles initiales

**Application dans un club d'investissement :**
Cette approche peut être particulièrement adaptée aux clubs d'investissement, car elle permet de définir collectivement une stratégie claire et de la maintenir dans le temps, tout en limitant les débats sur les ajustements tactiques.

## Critères de Pondération des Lignes dans le Portefeuille

### Pondération Égale

La pondération égale consiste à allouer le même pourcentage du portefeuille à chaque action.

**Exemple :** Dans un portefeuille de 20 actions, chaque action représente 5% du portefeuille.

**Avantages :**
- Simplicité de mise en œuvre
- Diversification naturelle
- Évite la concentration excessive
- Pas de biais en faveur des grandes capitalisations

**Inconvénients :**
- Ne tient pas compte des différences de risque entre les actions
- Peut surpondérer des actions à plus haut risque
- Nécessite des rééquilibrages fréquents

### Pondération par Capitalisation

La pondération par capitalisation consiste à allouer un pourcentage du portefeuille proportionnel à la capitalisation boursière de chaque entreprise.

**Exemple :** Si la capitalisation de l'entreprise A représente 2% de la capitalisation totale des entreprises du portefeuille, elle recevra 2% de l'allocation.

**Avantages :**
- Reflète la réalité du marché
- Moins de rééquilibrages nécessaires
- Favorise naturellement les entreprises plus grandes et souvent plus stables

**Inconvénients :**
- Concentration dans les plus grandes capitalisations
- Peut limiter le potentiel de surperformance
- Sous-représentation des petites capitalisations à fort potentiel

### Pondération par Conviction

La pondération par conviction consiste à allouer un pourcentage plus important aux actions pour lesquelles le club a une forte conviction.

**Exemple :** Les actions à forte conviction peuvent recevoir 5-10% du portefeuille, tandis que les actions à conviction modérée reçoivent 2-5%, et les actions à faible conviction 1-2%.

**Avantages :**
- Alignement avec les analyses et convictions du club
- Potentiel de surperformance si les convictions sont correctes
- Engagement plus fort des membres dans l'analyse

**Inconvénients :**
- Risque de concentration excessive
- Impact plus important des erreurs d'analyse
- Peut être influencé par des biais comportementaux

### Pondération par Risque

La pondération par risque vise à équilibrer la contribution de chaque action au risque global du portefeuille.

**Exemple :** Les actions plus volatiles reçoivent une pondération plus faible, tandis que les actions moins volatiles reçoivent une pondération plus élevée.

**Avantages :**
- Meilleure gestion du risque global
- Peut améliorer le ratio rendement/risque
- Approche plus sophistiquée et rigoureuse

**Inconvénients :**
- Plus complexe à mettre en œuvre
- Nécessite des calculs de volatilité et de corrélation
- Peut sous-pondérer des opportunités à fort potentiel mais plus volatiles

### Pondération Multi-factorielle

La pondération multi-factorielle combine plusieurs critères pour déterminer l'allocation optimale.

**Exemple :** Combinaison de critères comme la qualité fondamentale, le momentum, la valorisation et la conviction dans une matrice de scoring.

**Avantages :**
- Approche équilibrée et complète
- Intègre différentes dimensions d'analyse
- Peut être adaptée aux priorités spécifiques du club

**Inconvénients :**
- Plus complexe à mettre en œuvre et à maintenir
- Nécessite un consensus sur les critères et leur pondération
- Peut créer une fausse impression de précision scientifique

## Processus de Décision Collective pour l'Allocation

### Étapes Clés du Processus

1. **Définition des critères d'allocation**
   - Quels facteurs seront pris en compte?
   - Quelle importance relative pour chaque facteur?
   - Quelles limites de concentration par action, secteur, etc.?

2. **Collecte et analyse des données**
   - Analyse fondamentale des entreprises
   - Analyse technique et de momentum
   - Analyse sectorielle et macroéconomique

3. **Proposition d'allocation**
   - Préparation d'une proposition basée sur les critères définis
   - Documentation des justifications pour chaque allocation

4. **Discussion et ajustement collectif**
   - Présentation de la proposition au club
   - Débat et ajustements basés sur les inputs des membres
   - Recherche de consensus

5. **Décision finale et mise en œuvre**
   - Vote si nécessaire
   - Documentation de la décision finale
   - Exécution des transactions nécessaires

6. **Suivi et évaluation**
   - Suivi régulier de la performance
   - Évaluation périodique de l'efficacité du processus
   - Ajustements du processus si nécessaire

### Bonnes Pratiques pour la Décision Collective

- **Structurer le processus** : Définir clairement les étapes, les rôles et les responsabilités
- **Documenter les décisions** : Garder une trace des décisions et de leurs justifications
- **Éviter la pensée de groupe** : Encourager les opinions divergentes et le débat constructif
- **Limiter les biais comportementaux** : Être conscient des biais comme l'ancrage, la confirmation, etc.
- **Établir des règles claires** : Définir à l'avance comment les désaccords seront résolus
- **Répartir les responsabilités d'analyse** : Assigner différents secteurs ou entreprises à différents membres
- **Prévoir des révisions périodiques** : Planifier des sessions dédiées à l'évaluation du processus

## Règles Empiriques d'Allocation Adaptées aux Actions

### Règle de 100

La règle de 100 est traditionnellement utilisée pour déterminer l'allocation entre actions et obligations. Pour un portefeuille 100% actions, elle peut être adaptée pour déterminer l'allocation entre actions de croissance et actions de valeur.

**Adaptation pour un club d'actions :**
- Soustrayez votre âge moyen de 100
- Le résultat représente le pourcentage à allouer aux actions de croissance (plus volatiles)
- Le reste est à allouer aux actions de valeur (moins volatiles)

**Exemple :**
Si l'âge moyen des membres du club est de 45 ans :
- Actions de croissance : 100 - 45 = 55%
- Actions de valeur : 45%

**Considérations :**
- Cette règle peut être ajustée en fonction de la tolérance au risque collective du club
- Pour un club plus agressif, on peut partir de 110 ou 120 au lieu de 100
- Pour un club plus conservateur, on peut partir de 90 au lieu de 100

### Règle des 4%

La règle des 4% suggère de détenir 4% de son portefeuille en actions pour chaque année de son horizon d'investissement.

**Adaptation pour un club d'actions :**
- Déterminez l'horizon d'investissement moyen du club
- Multipliez cet horizon par 4%
- Le résultat représente le pourcentage à allouer aux actions à forte croissance/haut risque
- Le reste est à allouer aux actions plus stables/à dividendes

**Exemple :**
Si l'horizon d'investissement moyen du club est de 15 ans :
- Actions à forte croissance/haut risque : 15 × 4% = 60%
- Actions stables/à dividendes : 40%

### Règle de Larry Swedroe

La règle de Larry Swedroe établit une allocation en actions basée sur l'horizon d'investissement.

**Adaptation pour un club d'actions :**
Utilisez cette règle pour déterminer l'allocation entre différentes catégories d'actions selon leur niveau de risque :

| Horizon d'investissement (années) | Actions à haut risque | Actions à risque modéré | Actions à faible risque |
|-----------------------------------|----------------------|------------------------|------------------------|
| 0-3                               | 0%                   | 0%                     | 100%                   |
| 4-5                               | 0%                   | 30%                    | 70%                    |
| 6-7                               | 10%                  | 40%                    | 50%                    |
| 8-9                               | 20%                  | 50%                    | 30%                    |
| 10-11                             | 30%                  | 50%                    | 20%                    |
| 12-14                             | 40%                  | 40%                    | 20%                    |
| 15-19                             | 50%                  | 30%                    | 20%                    |
| 20+                               | 60%                  | 25%                    | 15%                    |

**Catégories d'actions par niveau de risque :**
- **Haut risque** : Small caps, marchés émergents, secteurs volatils (technologie, biotech)
- **Risque modéré** : Mid caps, marchés développés hors domestique, secteurs cycliques
- **Faible risque** : Large caps domestiques, secteurs défensifs, actions à dividendes
  `;

  const exerciceInteractif = `
## Exercice Interactif: Construction d'une Matrice d'Allocation

### Présentation de la Matrice

La matrice d'allocation est un outil qui permet d'évaluer systématiquement les actions selon plusieurs critères pour déterminer leur allocation optimale dans le portefeuille.

Voici un exemple de matrice avec 5 critères, chacun noté de 1 à 5 :

1. **Qualité fondamentale** : Solidité financière, avantages compétitifs, qualité du management
2. **Momentum** : Performance récente, tendance du cours, révisions des estimations
3. **Valorisation** : Ratios P/E, P/B, P/S, DCF, comparaison sectorielle
4. **Conviction** : Niveau de confiance dans l'analyse, consensus du club
5. **Fit stratégique** : Contribution à la diversification, alignement avec la stratégie du club

### Application à un Exemple Concret

Appliquons cette matrice à 5 actions de secteurs différents :

| Action | Secteur | Qualité (1-5) | Momentum (1-5) | Valorisation (1-5) | Conviction (1-5) | Fit stratégique (1-5) | Score total (max 25) | Allocation (%) |
|--------|---------|--------------|---------------|-------------------|-----------------|----------------------|---------------------|---------------|
| Air Liquide | Matériaux | 5 | 3 | 3 | 4 | 4 | 19 | ? |
| BNP Paribas | Finance | 4 | 4 | 5 | 3 | 3 | 19 | ? |
| LVMH | Cons. discrétionnaire | 5 | 5 | 2 | 5 | 3 | 20 | ? |
| Sanofi | Santé | 4 | 2 | 4 | 3 | 5 | 18 | ? |
| Dassault Systèmes | Technologie | 5 | 4 | 2 | 4 | 4 | 19 | ? |

### Calcul de l'Allocation

Pour calculer l'allocation basée sur les scores :

1. **Méthode proportionnelle simple** :
   - Additionnez tous les scores totaux : 19 + 19 + 20 + 18 + 19 = 95
   - Calculez le pourcentage pour chaque action : Score / Somme des scores
   - Air Liquide : 19/95 = 20%
   - BNP Paribas : 19/95 = 20%
   - LVMH : 20/95 = 21%
   - Sanofi : 18/95 = 19%
   - Dassault Systèmes : 19/95 = 20%

2. **Méthode avec seuils et plafonds** :
   - Définissez une allocation minimale (ex: 5%) et maximale (ex: 25%)
   - Ajustez les allocations proportionnelles pour respecter ces limites
   - Redistribuez l'excédent/déficit proportionnellement

3. **Méthode pondérée par critère** :
   - Attribuez des poids différents à chaque critère (ex: Conviction x2)
   - Recalculez les scores totaux pondérés
   - Calculez les allocations basées sur ces nouveaux scores
  `;

  const quizQuestions = [
    {
      question: "Quelle stratégie d'allocation est caractérisée par des ajustements fréquents du portefeuille en fonction de l'analyse des marchés?",
      options: [
        "Stratégie passive",
        "Stratégie active",
        "Stratégie stratégique",
        "Stratégie d'indexation"
      ],
      correctAnswer: 1,
      explanation: "La stratégie active implique des ajustements fréquents du portefeuille basés sur l'analyse des marchés, des secteurs et des entreprises individuelles, dans le but de surperformer le marché."
    },
    {
      question: "Dans un club d'investissement, quelle méthode de pondération pourrait être la plus adaptée pour refléter les différents niveaux de confiance dans les analyses?",
      options: [
        "Pondération égale",
        "Pondération par capitalisation",
        "Pondération par conviction",
        "Pondération par risque"
      ],
      correctAnswer: 2,
      explanation: "La pondération par conviction permet d'allouer un pourcentage plus important aux actions pour lesquelles le club a une forte confiance dans son analyse, reflétant ainsi le travail d'analyse collectif et les différents niveaux de certitude."
    },
    {
      question: "Selon la règle de 100 adaptée à un portefeuille d'actions, si l'âge moyen des membres d'un club est de 50 ans, quelle devrait être l'allocation approximative entre actions de croissance et actions de valeur?",
      options: [
        "50% croissance, 50% valeur",
        "70% croissance, 30% valeur",
        "30% croissance, 70% valeur",
        "100% croissance, 0% valeur"
      ],
      correctAnswer: 0,
      explanation: "Selon la règle de 100 adaptée, on soustrait l'âge moyen (50) de 100, ce qui donne 50% pour les actions de croissance, et donc 50% pour les actions de valeur."
    },
    {
      question: "Dans une matrice d'allocation multi-factorielle, quelle est la meilleure façon de déterminer les pondérations finales?",
      options: [
        "Allouer un pourcentage égal à chaque action",
        "Allouer proportionnellement aux scores totaux",
        "Allouer uniquement selon le critère de valorisation",
        "Allouer uniquement aux actions avec les scores les plus élevés"
      ],
      correctAnswer: 1,
      explanation: "Dans une matrice multi-factorielle, l'allocation proportionnelle aux scores totaux permet de refléter l'évaluation globale de chaque action selon tous les critères considérés, tout en assurant que les actions mieux notées reçoivent une pondération plus importante."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <ReactMarkdown>{content}</ReactMarkdown>
        
        <div className="mt-8 mb-4">
          <h2 className="text-xl font-semibold mb-4">Exercice Interactif: Construction d'une Matrice d'Allocation</h2>
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
            <ReactMarkdown>{exerciceInteractif}</ReactMarkdown>
            
            <div className="mt-6 bg-white border border-gray-200 rounded-lg p-4">
              <h3 className="font-semibold mb-3">Votre matrice d'allocation:</h3>
              
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead>
                    <tr>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left">Action</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-left">Secteur</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Qualité (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Momentum (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Valorisation (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Conviction (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Fit stratégique (1-5)</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Score total</th>
                      <th className="py-2 px-4 border-b border-gray-200 bg-gray-50 text-center">Allocation (%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { name: 'Action A', sector: 'Technologie' },
                      { name: 'Action B', sector: 'Finance' },
                      { name: 'Action C', sector: 'Santé' },
                      { name: 'Action D', sector: 'Industrie' },
                      { name: 'Action E', sector: 'Consommation' }
                    ].map((action, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                        <td className="py-2 px-4 border-b border-gray-200">{action.name}</td>
                        <td className="py-2 px-4 border-b border-gray-200">{action.sector}</td>
                        {[...Array(5)].map((_, i) => (
                          <td key={i} className="py-2 px-4 border-b border-gray-200 text-center">
                            <select className="border rounded p-1 w-12">
                              {[1, 2, 3, 4, 5].map(n => (
                                <option key={n} value={n}>{n}</option>
                              ))}
                            </select>
                          </td>
                        ))}
                        <td className="py-2 px-4 border-b border-gray-200 text-center">-</td>
                        <td className="py-2 px-4 border-b border-gray-200 text-center">-</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 text-right">
                <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                  Calculer l'allocation
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {!showQuiz ? (
          <div className="mt-8 text-center">
            <button
              onClick={() => setShowQuiz(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Passer au Quiz
            </button>
          </div>
        ) : (
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Quiz: Stratégies d'Allocation</h2>
            <QuizCard 
              questions={quizQuestions}
              onComplete={handleQuizComplete}
            />
            
            {quizCompleted && (
              <div className="mt-8 text-center">
                <button
                  onClick={onComplete}
                  className="px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Marquer cette section comme terminée
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Section3Methodology;
