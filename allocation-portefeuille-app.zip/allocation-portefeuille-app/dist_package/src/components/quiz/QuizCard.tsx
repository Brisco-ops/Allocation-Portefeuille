import React, { useState } from 'react';

interface QuizCardProps {
  questions: {
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }[];
  onComplete: (score: number) => void;
}

const QuizCard: React.FC<QuizCardProps> = ({ questions, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  
  const handleOptionSelect = (optionIndex: number) => {
    if (selectedOption !== null) return; // Déjà répondu
    
    setSelectedOption(optionIndex);
    
    if (optionIndex === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
    
    setShowExplanation(true);
  };
  
  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
      setShowExplanation(false);
    } else {
      setCompleted(true);
      onComplete(score);
    }
  };
  
  if (completed) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold mb-4">Quiz terminé!</h3>
        <p className="text-lg mb-4">
          Votre score: <span className="font-bold">{score}/{questions.length}</span>
        </p>
        <div className="mt-4">
          {score >= questions.length / 2 ? (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
              Félicitations! Vous avez réussi le quiz.
            </div>
          ) : (
            <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
              Vous pourriez revoir cette section pour mieux comprendre les concepts.
            </div>
          )}
        </div>
      </div>
    );
  }
  
  const currentQ = questions[currentQuestion];
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-4 text-sm text-gray-500">
        Question {currentQuestion + 1} sur {questions.length}
      </div>
      
      <h3 className="text-xl font-semibold mb-4">{currentQ.question}</h3>
      
      <div className="space-y-3 mb-6">
        {currentQ.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleOptionSelect(index)}
            className={`w-full text-left p-3 rounded-md border transition-colors ${
              selectedOption === null
                ? 'border-gray-300 hover:bg-gray-50'
                : selectedOption === index
                  ? index === currentQ.correctAnswer
                    ? 'border-green-500 bg-green-50'
                    : 'border-red-500 bg-red-50'
                  : index === currentQ.correctAnswer
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 opacity-70'
            }`}
            disabled={selectedOption !== null}
          >
            {option}
          </button>
        ))}
      </div>
      
      {showExplanation && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-md">
          <h4 className="font-semibold mb-2">Explication:</h4>
          <p>{currentQ.explanation}</p>
        </div>
      )}
      
      <div className="flex justify-end">
        <button
          onClick={handleNextQuestion}
          disabled={selectedOption === null}
          className={`px-4 py-2 rounded-md ${
            selectedOption === null
              ? 'bg-gray-300 cursor-not-allowed'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {currentQuestion < questions.length - 1 ? 'Question suivante' : 'Terminer le quiz'}
        </button>
      </div>
    </div>
  );
};

export default QuizCard;
