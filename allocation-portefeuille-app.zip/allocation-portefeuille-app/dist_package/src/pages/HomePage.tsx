import React from 'react';
import { Link } from 'react-router-dom';
import { useProgress } from '../context/ProgressContext';

const HomePage: React.FC = () => {
  const { getProgress, completedSections } = useProgress();
  
  const sections = [
    { 
      id: '1', 
      title: 'Les Fondamentaux de l\'Allocation', 
      description: 'Principes théoriques essentiels qui sous-tendent une allocation efficace entre différentes lignes d\'actions.',
      icon: '📊',
      duration: '4 minutes'
    },
    { 
      id: '2', 
      title: 'Stratégies de Diversification', 
      description: 'Différentes dimensions de diversification possibles dans un portefeuille composé uniquement d\'actions.',
      icon: '🔄',
      duration: '5 minutes'
    },
    { 
      id: '3', 
      title: 'Méthodologie d\'Allocation', 
      description: 'Approche structurée pour déterminer l\'allocation optimale entre différentes lignes d\'actions.',
      icon: '📋',
      duration: '5 minutes'
    },
    { 
      id: '4', 
      title: 'Gestion Dynamique et Rééquilibrage', 
      description: 'Aspect évolutif de l\'allocation et importance des ajustements périodiques.',
      icon: '⚖️',
      duration: '4 minutes'
    },
    { 
      id: '5', 
      title: 'Outils Pratiques', 
      description: 'Outils concrets pour mettre en œuvre efficacement les concepts et méthodologies présentés.',
      icon: '🛠️',
      duration: 'Variable'
    },
    { 
      id: '6', 
      title: 'Bonus - Ressources pour les Membres', 
      description: 'Ressources complémentaires pour approfondir vos connaissances et améliorer votre pratique.',
      icon: '🎁',
      duration: 'Hors formation'
    },
  ];

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold mb-4">L'Allocation des Lignes d'Actions dans le Portefeuille</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Formation interactive pour optimiser l'allocation entre différentes actions dans votre club d'investissement
        </p>
        
        <div className="mt-6">
          <div className="bg-blue-100 rounded-full h-6 w-full max-w-md mx-auto overflow-hidden">
            <div 
              className="bg-blue-600 h-full" 
              style={{ width: `${getProgress()}%` }}
            ></div>
          </div>
          <p className="mt-2 text-blue-800">
            {completedSections.length} sur 6 sections complétées ({Math.round(getProgress())}%)
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">
        {sections.map((section) => (
          <div 
            key={section.id}
            className={`border rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg ${
              completedSections.includes(section.id) ? 'border-green-500 bg-green-50' : 'border-gray-200'
            }`}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="text-3xl">{section.icon}</div>
                {completedSections.includes(section.id) && (
                  <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">Complété</span>
                )}
              </div>
              <h2 className="text-xl font-semibold mb-2">{section.title}</h2>
              <p className="text-gray-600 mb-4">{section.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">{section.duration}</span>
                <Link 
                  to={`/section/${section.id}`}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  {completedSections.includes(section.id) ? 'Revoir' : 'Commencer'}
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <h2 className="text-2xl font-semibold mb-4">Outils Interactifs</h2>
        <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
          <Link 
            to="/tools/allocation-matrix"
            className="px-6 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
          >
            Matrice d'Allocation
          </Link>
          <Link 
            to="/tools/arbitrage-form"
            className="px-6 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
          >
            Fiche d'Arbitrage
          </Link>
          <Link 
            to="/tools/dashboard"
            className="px-6 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
          >
            Tableau de Bord
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
