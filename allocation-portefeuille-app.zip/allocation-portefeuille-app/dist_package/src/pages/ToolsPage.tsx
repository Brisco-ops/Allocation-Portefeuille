import React from 'react';
import { Link } from 'react-router-dom';

const ToolsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Outils Interactifs d'Allocation</h1>
      
      <p className="text-lg text-gray-700 mb-8 text-center">
        Ces outils vous permettent d'appliquer concrètement les concepts vus dans la formation.
        Explorez-les pour optimiser l'allocation de votre portefeuille d'actions.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-40 bg-blue-600 flex items-center justify-center">
            <span className="text-5xl text-white">📊</span>
          </div>
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-2">Matrice d'Allocation</h2>
            <p className="text-gray-600 mb-4">
              Évaluez systématiquement vos actions selon plusieurs critères pour déterminer leur allocation optimale.
            </p>
            <Link 
              to="/tools/allocation-matrix"
              className="block w-full text-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Utiliser l'outil
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-40 bg-green-600 flex items-center justify-center">
            <span className="text-5xl text-white">📝</span>
          </div>
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-2">Fiche d'Arbitrage</h2>
            <p className="text-gray-600 mb-4">
              Formalisez et documentez vos décisions d'arbitrage entre différentes lignes d'actions.
            </p>
            <Link 
              to="/tools/arbitrage-form"
              className="block w-full text-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
            >
              Utiliser l'outil
            </Link>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <div className="h-40 bg-purple-600 flex items-center justify-center">
            <span className="text-5xl text-white">📈</span>
          </div>
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-2">Tableau de Bord</h2>
            <p className="text-gray-600 mb-4">
              Suivez en continu votre allocation et identifiez rapidement les écarts par rapport à vos cibles.
            </p>
            <Link 
              to="/tools/dashboard"
              className="block w-full text-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
            >
              Utiliser l'outil
            </Link>
          </div>
        </div>
      </div>
      
      <div className="mt-12 bg-gray-50 rounded-lg p-6 border border-gray-200">
        <h2 className="text-xl font-semibold mb-4">Téléchargements</h2>
        <p className="mb-4">
          Vous pouvez également télécharger ces outils au format Excel pour les utiliser hors ligne:
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors flex items-center justify-center">
            <span className="mr-2">📊</span> Matrice d'Allocation (Excel)
          </button>
          
          <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors flex items-center justify-center">
            <span className="mr-2">📝</span> Fiche d'Arbitrage (Excel)
          </button>
          
          <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors flex items-center justify-center">
            <span className="mr-2">📈</span> Tableau de Bord (Excel)
          </button>
        </div>
      </div>
      
      <div className="mt-8 text-center">
        <Link 
          to="/"
          className="inline-block px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          Retour à l'accueil
        </Link>
      </div>
    </div>
  );
};

export default ToolsPage;
