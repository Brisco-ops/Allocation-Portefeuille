import React from 'react';
import { useParams } from 'react-router-dom';
import { useProgress } from '../context/ProgressContext';

// Importation des composants de section
import Section1Fundamentals from '../components/sections/Section1Fundamentals';
import Section2Diversification from '../components/sections/Section2Diversification';
import Section3Methodology from '../components/sections/Section3Methodology';
import Section4DynamicManagement from '../components/sections/Section4DynamicManagement';
import Section5PracticalTools from '../components/sections/Section5PracticalTools';
import Section6Bonus from '../components/sections/Section6Bonus';

const SectionPage: React.FC = () => {
  const { sectionId } = useParams<{ sectionId: string }>();
  const { markSectionCompleted } = useProgress();
  
  // Fonction pour marquer la section comme complétée
  const handleComplete = () => {
    if (sectionId) {
      markSectionCompleted(sectionId);
    }
  };
  
  // Rendu conditionnel en fonction de l'ID de section
  const renderSection = () => {
    switch (sectionId) {
      case '1':
        return <Section1Fundamentals onComplete={handleComplete} />;
      case '2':
        return <Section2Diversification onComplete={handleComplete} />;
      case '3':
        return <Section3Methodology onComplete={handleComplete} />;
      case '4':
        return <Section4DynamicManagement onComplete={handleComplete} />;
      case '5':
        return <Section5PracticalTools onComplete={handleComplete} />;
      case '6':
        return <Section6Bonus onComplete={handleComplete} />;
      default:
        return <div className="text-center py-12">Section non trouvée</div>;
    }
  };
  
  return (
    <div className="py-6">
      {renderSection()}
    </div>
  );
};

export default SectionPage;
